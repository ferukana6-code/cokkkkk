// app.js - PuncakNusantara Ultimate

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    handleRoute();
    
    // Back to Top scroll listener
    window.addEventListener('scroll', () => {
        const btn = document.getElementById('back-to-top');
        if (btn) {
            if (window.scrollY > 400) btn.classList.add('visible');
            else btn.classList.remove('visible');
        }
    });
});

let currentTheme = localStorage.getItem('theme') || 'light';
let savedLogbook = JSON.parse(localStorage.getItem('puncakNusantara_logbook')) || [];

const appRoot = document.getElementById('app-root');
const themeToggleBtn = document.getElementById('theme-toggle');
const themeIcon = themeToggleBtn.querySelector('i');

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    if (theme === 'dark') {
        themeIcon.setAttribute('data-lucide', 'sun');
    } else {
        themeIcon.setAttribute('data-lucide', 'moon');
    }
    lucide.createIcons();
}

themeToggleBtn.addEventListener('click', () => {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    localStorage.setItem('theme', currentTheme);
    applyTheme(currentTheme);
});
applyTheme(currentTheme);

function handleRoute() {
    const hash = window.location.hash || '#home';
    const params = hash.split('/');
    const route = params[0].split('?')[0]; 
    
    window.scrollTo(0, 0);

    switch(route) {
        case '#home': renderHome(); break;
        case '#mountains': renderMountains(); break;
        case '#mountain': 
            if(params[1]) renderMountainDetail(decodeURIComponent(params[1]));
            else window.location.hash = '#mountains';
            break;
        case '#planner': renderPlanner(); break;
        case '#compare': renderCompare(); break;
        case '#logbook': renderLogbook(); break;
        case '#survival': renderSurvival(); break;
        default: renderHome();
    }
    lucide.createIcons();
    setTimeout(loadWikiImages, 100);
}

window.addEventListener('hashchange', handleRoute);

function getDifficultyBadge(diff) {
    const map = {1: 'Pemula / Tektok', 2: 'Menengah', 3: 'Sulit', 4: 'Ekstrem / Ekspedisi'};
    return `<span class="badge badge-diff-${diff}">${map[diff] || 'Unknown'}</span>`;
}

function getStatusBadge(status) {
    if(status.includes('DITUTUP') || status.includes('TERLARANG')) return `<span class="badge" style="background:#dc3545;color:white;">DITUTUP</span>`;
    return `<span class="badge ${status === 'Aktif' ? 'badge-active' : 'badge-inactive'}">${status}</span>`;
}

// LOGIKA SAFETY SCORE (1-10)
function getSafetyScore(m, weatherScoreMod = 0) {
    let score = 8;
    if(m.status === 'Aktif') score -= 2;
    if(m.difficulty === 3) score -= 1;
    if(m.difficulty === 4) score -= 2;
    if(m.status.includes('DITUTUP') || m.status.includes('TERLARANG')) score = 1;

    score += weatherScoreMod;
    score = Math.max(1, Math.min(10, score));

    return score;
}

function getSafetyBadgeHtml(score) {
    if(score >= 8) return `<span class="badge" style="background:#28a745;color:white;"><i data-lucide="shield-check" style="width:14px; height:14px;"></i> Aman (${score}/10)</span>`;
    if(score >= 5) return `<span class="badge" style="background:#ffc107;color:black;"><i data-lucide="shield-alert" style="width:14px; height:14px;"></i> Waspada (${score}/10)</span>`;
    return `<span class="badge" style="background:#dc3545;color:white;"><i data-lucide="shield-x" style="width:14px; height:14px;"></i> Hindari (${score}/10)</span>`;
}

// DATA REAL: Estimasi Jarak & Durasi berdasarkan pengalaman pendaki (bukan rumus)
const trekData = {
    // JAWA BARAT & BANTEN
    'gede': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},'pangrango': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},
    'salak': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},'ciremai': {dist:'~18 km (PP)',dur:'2 Hari 1 Malam'},
    'papandayan': {dist:'~7 km (PP)',dur:'Tektok (1 Hari)'},'cikuray': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},
    'guntur': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'galunggung': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'burangrang': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'tangkuban-parahu': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'malabar': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'manglayang': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'tampomas': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'kencana': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'lembu': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},'parang': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'bongkok': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},'munara': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'batu-jonggol': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},'pulosari': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'karang': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'sanggabuana': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'patuha': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'artapela': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'hejo': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'pancar': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'tilu': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'kendang': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},
    'masigit': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'lalakon': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'buligir': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'subang': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    
    // JAWA TENGAH & DIY
    'slamet': {dist:'~22 km (PP)',dur:'3 Hari 2 Malam'},'sumbing': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},
    'sindoro': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},'prau': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'merbabu': {dist:'~18 km (PP)',dur:'2 Hari 1 Malam'},'merapi': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},
    'andong': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},'ungaran': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'muria': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'bisma': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'pakuwaja': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},'telomoyo': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'kembang': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'lawu': {dist:'~16 km (PP)',dur:'2 Hari 1 Malam'},
    'nglanggeran': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'sikunir': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'mongkrang': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'rogojembangan': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'sipandu': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'blego': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'gandul': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'beser': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'kombang': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'srandil': {dist:'~1 km (PP)',dur:'Tektok (1 Hari)'},
    'cumbri': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'sepikul': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    
    // JAWA TIMUR
    'semeru': {dist:'~36 km (PP)',dur:'3 Hari 2 Malam'},'arjuno': {dist:'~20 km (PP)',dur:'2 Hari 1 Malam'},
    'welirang': {dist:'~16 km (PP)',dur:'2 Hari 1 Malam'},'penanggungan': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'kelud': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},'kawi': {dist:'~10 km (PP)',dur:'Tektok (1 Hari)'},
    'butak': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},'panderman': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'raung': {dist:'~30 km (PP)',dur:'4 Hari 3 Malam'},'argopuro': {dist:'~42 km (PP)',dur:'5 Hari 4 Malam'},
    'ijen': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'baluran': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'lemongan': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'pundak': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'lorokan': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},'wilis': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},
    'bromo': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},'batok': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'suket': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},
    'ringgit': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'klotok': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'pegat': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'budheg': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'liman': {dist:'~18 km (PP)',dur:'3 Hari 2 Malam'},
    'penanjakan': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'argowayang': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'anjasmoro': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},
    'puthuk-siwur': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-klesih': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-gragal': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kenthalo': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-lesung': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-panggang-welut': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-truno': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kembang': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-suko': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-sukosewu': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-sewu': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kursi': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-ijo': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-tleser': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-genthong': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kreweng': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-jeding': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-puyang': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-cemoro': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-mongkrang-jawatimur': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kendil': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kenthur': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kembar': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-lirang': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-petung': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-mangir': {dist:'~2 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kencur': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'puthuk-kresek': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    
    // SUMATERA
    'kerinci': {dist:'~20 km (PP)',dur:'3 Hari 2 Malam'},'leuser': {dist:'~60 km (PP)',dur:'10-14 Hari (Ekspedisi)'},
    'sibayak': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},'sinabung': {dist:'DITUTUP',dur:'DITUTUP PERMANEN'},
    'pusuk-buhit': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'sorik-marapi': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},
    'talamau': {dist:'~14 km (PP)',dur:'3 Hari 2 Malam'},'singgalang': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'marapi': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},'tandikat': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'talang': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},'sago': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'dempo': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},'pesagi': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},
    'rajabasa': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'tanggamus': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'seminung': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'bandahara': {dist:'~16 km (PP)',dur:'3 Hari 2 Malam'},
    'bukit-kaba': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'masurai': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},
    'seulawah-agam': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'daik': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},
    'ranai': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'geureudong': {dist:'~18 km (PP)',dur:'3 Hari 2 Malam'},
    'danau-tujuh': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'sibuaten': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'pesawaran': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'kemiri': {dist:'~22 km (PP)',dur:'4 Hari 3 Malam'},
    'perkison': {dist:'~16 km (PP)',dur:'3 Hari 2 Malam'},
    'patah': {dist:'~24 km (PP)',dur:'5 Hari 4 Malam'},
    'seulawah-inong': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'bungkuk': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'jantan': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'betung': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'lubuk-raya': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},
    'sekincau': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},
    'goh-lemuh': {dist:'~16 km (PP)',dur:'3 Hari 2 Malam'},
    'abong-abong': {dist:'~32 km (PP)',dur:'5 Hari 4 Malam'},
    
    // NUSA TENGGARA & BALI
    'agung': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},'batur': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'abang': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'batukaru': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'rinjani': {dist:'~34 km (PP)',dur:'4 Hari 3 Malam'},'tambora': {dist:'~18 km (PP)',dur:'3 Hari 2 Malam'},
    'sangeang-api': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},'inerie': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'egon': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'kelimutu': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'rokatenda': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},'mutis': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'pergasingan': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'iya': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'lewotobi': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'sirung': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'boleng': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'nanggi': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'catur': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'sanghyang': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'pohen': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'ile-ape': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'pal-jepang': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'kondo': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    
    // SULAWESI & MALUKU
    'latimojong': {dist:'~22 km (PP)',dur:'4 Hari 3 Malam'},'bawakaraeng': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},
    'lompobattang': {dist:'~16 km (PP)',dur:'3 Hari 2 Malam'},'karangetang': {dist:'DITUTUP',dur:'DITUTUP'},
    'awu': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},'lokon': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'mahawu': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},'soputan': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'klabat': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},'binaiya': {dist:'~50 km (PP)',dur:'7-10 Hari (Ekspedisi)'},
    'gamalama': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},'gamkonora': {dist:'~8 km (PP)',dur:'2 Hari 1 Malam'},
    'ibu': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},'dukono': {dist:'~10 km (PP)',dur:'2 Hari 1 Malam'},
    'kie-besi': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'gandang-dewata': {dist:'~36 km (PP)',dur:'8 Hari 7 Malam'},
    'mekongga': {dist:'~28 km (PP)',dur:'5 Hari 4 Malam'},
    'bulusaraung': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'nokilalaki': {dist:'~14 km (PP)',dur:'2 Hari 1 Malam'},
    'rorekatimbu': {dist:'~8 km (PP)',dur:'Tektok (1 Hari)'},
    'empung': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'ambang': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'},
    'kabobong': {dist:'~3 km (PP)',dur:'Tektok (1 Hari)'},
    'sikolong': {dist:'~18 km (PP)',dur:'4 Hari 3 Malam'},
    'balease': {dist:'~28 km (PP)',dur:'6 Hari 5 Malam'},
    
    // KALIMANTAN & PAPUA
    'puncak-jaya': {dist:'~30 km (PP)',dur:'7-12 Hari (Ekspedisi)'},'trikora': {dist:'~20 km (PP)',dur:'5-7 Hari (Ekspedisi)'},
    'mandala': {dist:'Tidak Ada Jalur',dur:'Ekspedisi Khusus'},'yamin': {dist:'Tidak Ada Jalur',dur:'Ekspedisi Khusus'},
    'cycloop': {dist:'~12 km (PP)',dur:'2 Hari 1 Malam'},'bukit-raya': {dist:'~24 km (PP)',dur:'5-7 Hari (Ekspedisi)'},
    'batu-daya': {dist:'~2 km (PP)',dur:'Tektok (Panjat Tebing)'},
    'poteng': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'niut': {dist:'~20 km (PP)',dur:'3 Hari 2 Malam'},
    'mandi': {dist:'~4 km (PP)',dur:'Tektok (1 Hari)'},
    'birang': {dist:'~5 km (PP)',dur:'Tektok (1 Hari)'},
    'gunung-besar': {dist:'~16 km (PP)',dur:'3 Hari 2 Malam'},
    'periuk': {dist:'~6 km (PP)',dur:'Tektok (1 Hari)'}
};

function getTrekEstimates(elevation, difficulty, id) {
    if (id && trekData[id]) return { distancePP: trekData[id].dist, duration: trekData[id].dur };
    // Fallback sederhana jika id tidak ada di database
    let dur = elevation >= 3000 ? '2 Hari 1 Malam' : 'Tektok (1 Hari)';
    return { distancePP: '~? km', duration: dur };
}

function getContactInfo(m) {
    let info = {
        simaksiUrl: "",
        simaksiText: "Registrasi di Basecamp (On the Spot)"
    };
    
    if (m.nationalPark === 'TNGGP' || m.id === 'gede' || m.id === 'pangrango') {
        info.simaksiUrl = "https://booking.tnggp.menlhk.go.id/";
        info.simaksiText = "Booking Online TNGGP (Wajib)";
    } else if (m.nationalPark === 'TNBTS' || m.id === 'semeru' || m.id === 'bromo') {
        info.simaksiUrl = "https://bookingbromo.bromotenggersemeru.org/";
        info.simaksiText = "Booking Online TNBTS (Wajib)";
    } else if (m.id === 'merbabu') {
        info.simaksiUrl = "https://booking.tngunungmerbabu.org/";
        info.simaksiText = "Booking Online Merbabu";
    } else if (m.nationalPark === 'TNGR' || m.id === 'rinjani') {
        info.simaksiUrl = "https://erinjani.id/";
        info.simaksiText = "eRinjani Booking App";
    } else if (m.nationalPark === 'TNGC' || m.id === 'ciremai') {
        info.simaksiUrl = "https://bookingciremai.menlhk.go.id/";
        info.simaksiText = "Booking Online Ciremai";
    } else if (m.id === 'prau') {
        info.simaksiText = "Info Registrasi Prau";
        info.simaksiUrl = "https://wa.me/6281234561234"; // Keeping WhatsApp link but removed phone text display
    } else if (m.id === 'sindoro' || m.id === 'sumbing') {
        info.simaksiUrl = "https://play.google.com/store/apps/details?id=com.sindorosumbing";
        info.simaksiText = "Via Aplikasi Smartphone";
    }

    return info;
}

// REAL IMAGE MATCHER USING WIKIPEDIA API
window.loadWikiImages = function() {
    const elems = document.querySelectorAll('.wiki-img:not(.loaded)');
    elems.forEach(async (el) => {
        el.classList.add('loaded');
        const name = el.getAttribute('data-wiki-img');
        if (!name) return;
        
        const tryFetch = async (titleQuery) => {
            const url = `https://id.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(titleQuery)}&prop=pageimages&format=json&pithumbsize=1000&origin=*`;
            const res = await fetch(url);
            const data = await res.json();
            const pages = data.query.pages;
            const pageId = Object.keys(pages)[0];
            if (pageId !== "-1" && pages[pageId].thumbnail) return pages[pageId].thumbnail.source;
            return null;
        };

        try {
            let imgSrc = await tryFetch(`Gunung_${name}`);
            if (!imgSrc) imgSrc = await tryFetch(name);
            if (!imgSrc) return;

            if (el.tagName === 'IMG') {
                // Legacy img tag (detail header)
                el.src = imgSrc;
            } else {
                // Explorer card: set clean background without extra overlay (CSS handles it)
                el.style.backgroundImage = `url('${imgSrc}')`;
            }
        } catch(e) {}
    });
}

function renderHome() {
    const featured = mountains.filter(m => ['semeru', 'rinjani', 'kerinci', 'merbabu'].includes(m.id));
    if(featured.length < 4) featured.push(...mountains.slice(0, 4 - featured.length));
    
    const html = `
        <section class="hero">
            <h1>PuncakNusantara <span>Ultimate</span></h1>
            <p>Database Gunung Terlengkap di Indonesia. Temukan info rute, cuaca, GPX, review, safety score, dan kalkulator biaya pendakian.</p>
            <div class="search-bar">
                <input type="text" id="global-search" placeholder="Cari gunung (Gede, Merbabu, dsb)..." onkeypress="handleSearch(event)">
                <button onclick="executeSearch()"><i data-lucide="search"></i></button>
            </div>
            <div class="quick-filters">
                <span class="quick-filter-tag" onclick="location.hash='#mountains?region=Jawa Barat'">Jawa Barat</span>
                <span class="quick-filter-tag" onclick="location.hash='#mountains?region=Jawa Tengah'">Jawa Tengah</span>
                <span class="quick-filter-tag" onclick="location.hash='#mountains?region=Jawa Timur'">Jawa Timur</span>
                <span class="quick-filter-tag" onclick="location.hash='#mountains?region=Sumatera'">Sumatera</span>
                <span class="quick-filter-tag" onclick="location.hash='#mountains?region=Sulawesi'">Sulawesi</span>
            </div>
        </section>
        
        <section class="container py-5">
            <div class="stats-container mb-4">
                <div class="stat-item">
                    <div class="stat-num">${mountains.length}</div>
                    <div class="stat-label">Gunung Terdaftar</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">${mountains.filter(m=>m.hasGpx).length}</div>
                    <div class="stat-label">Jalur Ber-GPX</div>
                </div>
                <div class="stat-item">
                    <div class="stat-num">${mountains.filter(m=>m.elevation < 2000).length}</div>
                    <div class="stat-label">Gunung Pemula (<2000mdpl)</div>
                </div>
            </div>
        </section>

        <section class="container py-5" style="margin-top:-20px;">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--color-border); padding-bottom:12px; margin-bottom:20px;">
                <h2 style="margin:0; font-size:1.5rem;"><i data-lucide="trophy"></i> Pencapaian Pendaki</h2>
                <span class="badge" style="background:var(--color-accent); color:white;">Gamifikasi</span>
            </div>
            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:15px;" id="achievements-grid">
                ${getAchievementsHtml()}
            </div>
        </section>

        <section class="container py-5" style="margin-top:-20px;">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--color-border); padding-bottom:12px; margin-bottom:20px;">
                <h2 style="margin:0; font-size:1.5rem;"><i data-lucide="newspaper"></i> Berita Terkini Pendakian</h2>
                <span class="badge" style="background:var(--color-primary); color:white; animation: pulse 2s infinite;">Live Update</span>
            </div>
            <div id="news-slider-container" style="position:relative; width:100%; height:320px; border-radius:16px; overflow:hidden; background:#222; box-shadow:0 10px 25px rgba(0,0,0,0.15);">
                <div id="news-slides" style="display:flex; width:100%; height:100%; transition:transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);">
                    <div style="min-width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; color:white;">
                        <i data-lucide="loader" style="animation: spin 1s linear infinite; margin-bottom:10px;"></i>
                        <p>Menarik berita terbaru dari satelit...</p>
                    </div>
                </div>
                <!-- Navigation Dots -->
                <div id="news-dots" style="position:absolute; bottom:20px; left:50%; transform:translateX(-50%); display:flex; gap:10px; z-index:10;"></div>
            </div>
        </section>

        <section class="container py-5">
            <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--color-border); padding-bottom:12px; margin-bottom:20px;">
                <h2 style="margin:0; font-size:1.5rem;"><i data-lucide="compass"></i> Rekomendasi Hari Ini</h2>
                <span class="badge" style="background:var(--color-primary); color:white;">Daily Pick</span>
            </div>
            ${getMountainOfTheDayHtml()}
        </section>

        <section class="container py-5">
            <h2 class="section-title text-center">Gunung Terpopuler</h2>
            <div class="grid">
                ${featured.map(mountainCardTemplate).join('')}
            </div>
            <div class="text-center mt-4">
                <a href="#mountains" class="btn btn-outline">Lihat Seluruh Database Gunung</a>
            </div>
        </section>
    `;
    appRoot.innerHTML = html;
    fetchNews();
}

window.handleSearch = function(e) { if(e.key === 'Enter') executeSearch(); }
window.executeSearch = function() {
    const query = document.getElementById('global-search').value;
    window.location.hash = '#mountains?q=' + encodeURIComponent(query);
}

window.fetchNews = async function() {
    const slidesContainer = document.getElementById('news-slides');
    const dotsContainer = document.getElementById('news-dots');
    if(!slidesContainer) return;
    
    try {
        // Query disempurnakan: Fokus ke alam, cuaca, wisata, gunung. Dikecualikan: UIN, universitas, jalan, kriminal
        const query = '("wisata alam" OR "bencana alam" OR "cuaca ekstrem" OR "pendakian" OR "taman nasional" OR "keindahan alam" OR "erupsi" OR "BMKG") -UIN -universitas -kampus -polisi -jalan';
        const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(query)}+when:3d&hl=id&gl=ID&ceid=ID:id`;
        const api = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`;
        
        const res = await fetch(api);
        const data = await res.json();
        
        if(data.status === 'ok' && data.items && data.items.length > 0) {
            const newsItems = data.items.slice(0, 10); // Diperbanyak menjadi 10 berita
            let slidesHtml = '';
            let dotsHtml = '';
            
            // 10 Gambar pegunungan/alam premium untuk fallback agar tidak bosan
            const fallbacks = [
                'https://images.unsplash.com/photo-1542224566-6e85f2e6772f?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1454496522488-7a8e488e8606?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1600298882283-40b4dcb8b211?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1470071131384-001b85755b36?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1444464666168-49b626d49c81?q=80&w=1200&auto=format&fit=crop',
                'https://images.unsplash.com/photo-1433086966358-54859d0ed716?q=80&w=1200&auto=format&fit=crop'
            ];
            
            newsItems.forEach((item, index) => {
                const date = new Date(item.pubDate);
                const timeAgo = Math.floor((new Date() - date) / (1000 * 60 * 60));
                let timeStr = "Baru saja";
                if(timeAgo > 0 && timeAgo < 24) timeStr = `${timeAgo} jam yang lalu`;
                else if(timeAgo >= 24) timeStr = `${Math.floor(timeAgo/24)} hari yang lalu`;
                
                // Selalu gunakan fallback gambar premium agar slider terlihat sangat elegan dan cocok
                let imgSrc = fallbacks[index % fallbacks.length];
                
                const titleParts = item.title.split(' - ');
                const source = titleParts.length > 1 ? titleParts.pop() : 'Berita Lokal';
                const title = titleParts.join(' - ') || item.title;
                
                slidesHtml += `
                    <div style="min-width:100%; height:100%; position:relative; background:url('${imgSrc}') center/cover;">
                        <div style="position:absolute; top:0; left:0; right:0; bottom:0; background:linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0.1) 100%);"></div>
                        
                        <a href="${item.link}" target="_blank" style="position:absolute; bottom:0; left:0; right:0; padding:40px 30px; text-decoration:none; color:white; display:flex; flex-direction:column; justify-content:flex-end; height:100%;">
                            <div>
                                <span style="background:var(--color-primary); color:white; padding:5px 12px; border-radius:6px; font-size:0.85rem; font-weight:bold; margin-bottom:15px; display:inline-block; letter-spacing:0.5px;">${source}</span>
                                <h3 style="margin:0 0 12px 0; font-size:1.6rem; font-family:var(--font-heading); line-height:1.3; text-shadow:0 2px 10px rgba(0,0,0,0.8); display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${title}</h3>
                                <div style="font-size:0.95rem; color:rgba(255,255,255,0.85); display:flex; align-items:center; gap:6px;">
                                    <i data-lucide="clock" style="width:16px; height:16px;"></i> ${timeStr} &nbsp;&bull;&nbsp; Baca selengkapnya &rarr;
                                </div>
                            </div>
                        </a>
                    </div>
                `;
                
                dotsHtml += `<div class="news-dot" onclick="goToNewsSlide(${index})" style="width:12px; height:12px; border-radius:50%; background:${index === 0 ? 'var(--color-accent)' : 'rgba(255,255,255,0.4)'}; cursor:pointer; transition:all 0.3s ease; box-shadow:0 2px 5px rgba(0,0,0,0.5);"></div>`;
            });
            
            slidesContainer.innerHTML = slidesHtml;
            dotsContainer.innerHTML = dotsHtml;
            lucide.createIcons();
            
            // Logika Auto Slide
            if(window.newsSlideInterval) clearInterval(window.newsSlideInterval);
            window.currentNewsSlide = 0;
            window.totalNewsSlides = newsItems.length;
            
            window.newsSlideInterval = setInterval(() => {
                goToNewsSlide((window.currentNewsSlide + 1) % window.totalNewsSlides);
            }, 5000);
            
        } else {
            slidesContainer.innerHTML = `<div style="min-width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:var(--color-text-light);">Belum ada berita terbaru hari ini.</div>`;
        }
    } catch (err) {
        slidesContainer.innerHTML = `<div style="min-width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:var(--color-text-light);">Gagal memuat berita. Cek koneksi Anda.</div>`;
    }
}

window.goToNewsSlide = function(index) {
    const slidesContainer = document.getElementById('news-slides');
    if(!slidesContainer) return;
    
    window.currentNewsSlide = index;
    slidesContainer.style.transform = `translateX(-${index * 100}%)`;
    
    // Update active dot
    const dots = document.querySelectorAll('.news-dot');
    dots.forEach((dot, i) => {
        dot.style.background = i === index ? 'var(--color-accent)' : 'rgba(255,255,255,0.4)';
        dot.style.transform = i === index ? 'scale(1.3)' : 'scale(1)';
    });
    
    // Reset timer jika diklik manual
    if(event && event.type === 'click') {
        clearInterval(window.newsSlideInterval);
        window.newsSlideInterval = setInterval(() => {
            goToNewsSlide((window.currentNewsSlide + 1) % window.totalNewsSlides);
        }, 5000);
    }
}

function mountainCardTemplate(m) {
    const placeholder = 'https://images.unsplash.com/photo-1589308078059-e14115e44c4b?q=80&w=600&auto=format&fit=crop';
    const baseSafetyScore = getSafetyScore(m);
    const est = getTrekEstimates(m.elevation, m.difficulty, m.id);
    const diffLabel = {1:'Pemula', 2:'Menengah', 3:'Sulit', 4:'Ekstrem'}[m.difficulty] || '?';
    const diffColor = {1:'#34d399', 2:'#fbbf24', 3:'#fb923c', 4:'#f87171'}[m.difficulty] || '#888';
    const statusColor = m.status === 'Aktif' ? '#f87171' : '#34d399';
    // Elevation gauge: max ref 5000m
    const elevPct = Math.min(Math.round((m.elevation / 5000) * 100), 100);
    
    return `
        <a href="#mountain/${m.id}" class="mountain-explorer-card wiki-img" data-wiki-bg="${m.name}" style="background-image: url(${placeholder});">
            <div class="mec-overlay"></div>
            
            <div class="mec-body">
                <!-- Left side: elevation bar -->
                <div class="mec-elev-col">
                    <div class="mec-elev-bar-track">
                        <div class="mec-elev-bar-fill" style="height:${elevPct}%; background: linear-gradient(to top, ${diffColor}, rgba(255,255,255,0.6));"></div>
                    </div>
                    <div class="mec-elev-num">${(m.elevation / 1000).toFixed(1)}k</div>
                    <div class="mec-elev-unit">mdpl</div>
                </div>

                <!-- Center: main info -->
                <div class="mec-info">
                    <div class="mec-location">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        ${m.province}
                    </div>
                    <h3 class="mec-name">${m.name}</h3>
                    ${m.localName ? `<div class="mec-alias">${m.localName}</div>` : ''}
                    <p class="mec-desc">${m.description.substring(0, 80)}${m.description.length > 80 ? '...' : ''}</p>
                    
                    <div class="mec-stats">
                        <div class="mec-stat-item">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            ${est.duration}
                        </div>
                        <div class="mec-stat-item">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                            ${est.distancePP}
                        </div>
                        ${m.hasGpx ? `<div class="mec-stat-item" style="color:#5eead4;">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/></svg>
                            GPX
                        </div>` : ''}
                    </div>
                </div>

                <!-- Right: badges -->
                <div class="mec-badges">
                    <div class="mec-diff-pill" style="background:${diffColor}15; color:${diffColor}; border:1px solid ${diffColor}40;">${diffLabel}</div>
                    <div class="mec-status-dot" style="background:${statusColor}20; color:${statusColor}; border:1px solid ${statusColor}40;">
                        <span style="width:6px; height:6px; border-radius:50%; background:${statusColor}; display:inline-block;"></span>
                        ${m.status}
                    </div>
                    <div class="mec-safety">
                        <div style="font-size:0.65rem; color:rgba(255,255,255,0.5); margin-bottom:3px;">Safety</div>
                        <div style="font-size:1.1rem; font-weight:900; color:${baseSafetyScore >= 7 ? '#34d399' : baseSafetyScore >= 5 ? '#fbbf24' : '#f87171'}">${baseSafetyScore}<span style="font-size:0.65rem; opacity:0.6;">/10</span></div>
                    </div>
                </div>
            </div>

            <!-- Bottom accent bar for difficulty -->
            <div class="mec-bottom-bar" style="background: linear-gradient(90deg, ${diffColor}, transparent);"></div>
        </a>
    `;
}

function renderMountains() {
    const hash = window.location.hash;
    let initialSearch = '';
    let initialRegion = '';
    
    if (hash.includes('?')) {
        const params = new URLSearchParams(hash.split('?')[1]);
        initialSearch = params.get('q') || '';
        initialRegion = params.get('region') || '';
    }

    let filtered = [...mountains];
    filtered.sort((a,b) => b.elevation - a.elevation);

    const html = `
        <div class="container py-5">
            <h1 class="section-title">Database Ratusan Gunung Indonesia</h1>
            
            <div class="filters-section">
                <div class="filter-group">
                    <label>Pencarian Nama</label>
                    <input type="text" id="filter-search" placeholder="Cari nama gunung..." oninput="filterMountains()" value="${initialSearch}">
                </div>
                <div class="filter-group">
                    <label>Provinsi / Region</label>
                    <select id="filter-province" onchange="filterMountains()">
                        <option value="">Seluruh Indonesia</option>
                        <option value="Jawa Barat" ${initialRegion==='Jawa Barat'?'selected':''}>Jawa Barat & Banten</option>
                        <option value="Jawa Tengah" ${initialRegion==='Jawa Tengah'?'selected':''}>Jawa Tengah & DIY</option>
                        <option value="Jawa Timur" ${initialRegion==='Jawa Timur'?'selected':''}>Jawa Timur</option>
                        <option value="Sumatera" ${initialRegion.includes('Sumatera')?'selected':''}>Sumatera</option>
                        <option value="Bali" ${initialRegion.includes('Bali')?'selected':''}>Bali & Nusa Tenggara</option>
                        <option value="Sulawesi" ${initialRegion.includes('Sulawesi')?'selected':''}>Sulawesi & Maluku</option>
                        <option value="Kalimantan" ${initialRegion.includes('Kalimantan')?'selected':''}>Kalimantan</option>
                        <option value="Papua" ${initialRegion.includes('Papua')?'selected':''}>Papua</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Level Kesulitan</label>
                    <select id="filter-diff" onchange="filterMountains()">
                        <option value="">Semua Level</option>
                        <option value="1">1 - Pemula / Tektok</option>
                        <option value="2">2 - Menengah</option>
                        <option value="3">3 - Sulit</option>
                        <option value="4">4 - Ekstrem / Ekspedisi</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Fitur Tambahan</label>
                    <select id="filter-gpx" onchange="filterMountains()">
                        <option value="">Semua Data</option>
                        <option value="has_gpx">Hanya yang memiliki GPX</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>Urutkan</label>
                    <select id="filter-sort" onchange="filterMountains()">
                        <option value="high">Ketinggian: Tertinggi</option>
                        <option value="low">Ketinggian: Terendah</option>
                        <option value="diff_high">Kesulitan: Sulit -> Mudah</option>
                        <option value="diff_low">Kesulitan: Mudah -> Sulit</option>
                    </select>
                </div>
            </div>

            <div class="grid" id="mountains-grid">
                ${filtered.map(mountainCardTemplate).join('')}
            </div>
        </div>
    `;
    appRoot.innerHTML = html;
    
    filterMountains();
}

window.filterMountains = function() {
    const search = document.getElementById('filter-search').value.toLowerCase().trim();
    const prov = document.getElementById('filter-province').value;
    const diff = document.getElementById('filter-diff').value;
    const hasGpx = document.getElementById('filter-gpx').value;
    const sortMethod = document.getElementById('filter-sort').value;
    
    let filtered = mountains.filter(m => {
        const matchSearch = search === "" || 
                            m.name.toLowerCase().includes(search) || 
                            m.province.toLowerCase().includes(search) || 
                            m.region.toLowerCase().includes(search) || 
                            (m.localName && m.localName.toLowerCase().includes(search)) ||
                            m.id.toLowerCase().includes(search);
                            
        let matchProv = false;
        if (prov === "") {
            matchProv = true;
        } else if (prov === "Jawa Barat") {
            matchProv = m.province.includes("Jawa Barat") || m.province === "Banten";
        } else if (prov === "Jawa Tengah") {
            matchProv = m.province.includes("Jawa Tengah") || m.province.includes("DIY");
        } else if (prov === "Jawa Timur") {
            matchProv = m.province.includes("Jawa Timur") || m.province.includes("Jatim");
        } else if (prov === "Sumatera") {
            matchProv = m.province.includes("Sumatera") || m.province === "Aceh" || m.province === "Jambi" || m.province.includes("Lampung") || m.province === "Bengkulu" || m.province.includes("Riau");
        } else if (prov === "Bali") {
            matchProv = m.province.includes("Bali") || m.province.includes("NT");
        } else if (prov === "Sulawesi") {
            matchProv = m.province.includes("Sulawesi") || m.province.includes("Maluku");
        } else {
            matchProv = m.province.includes(prov);
        }
        let matchDiff = diff === "" || m.difficulty.toString() === diff;
        let matchGpx = hasGpx === "" || (hasGpx === "has_gpx" && m.hasGpx);
        return matchSearch && matchProv && matchDiff && matchGpx;
    });

    if(sortMethod === 'high') filtered.sort((a,b) => b.elevation - a.elevation);
    else if(sortMethod === 'low') filtered.sort((a,b) => a.elevation - b.elevation);
    else if(sortMethod === 'diff_high') filtered.sort((a,b) => b.difficulty - a.difficulty);
    else if(sortMethod === 'diff_low') filtered.sort((a,b) => a.difficulty - b.difficulty);
    
    document.getElementById('mountains-grid').innerHTML = filtered.map(mountainCardTemplate).join('');
    lucide.createIcons();
    loadWikiImages(); 
}


// DETAIL GUNUNG
function renderMountainDetail(id) {
    const m = mountains.find(x => x.id === id);
    if(!m) {
        appRoot.innerHTML = `<div class="container py-5"><h2>Gunung tidak ditemukan.</h2></div>`;
        return;
    }
    
    // Simpan referensi gunung aktif untuk digunakan oleh sistem AI
    window.currentMountain = m;

    const savedComments = JSON.parse(localStorage.getItem('comments_' + m.id)) || [];
    const placeholder = 'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.8)), url(https://images.unsplash.com/photo-1589308078059-e14115e44c4b?q=80&w=1920&auto=format&fit=crop)';

    const baseSafetyScore = getSafetyScore(m);
    const contactInfo = getContactInfo(m);

    const html = `
        <div class="detail-header wiki-img" style="background: ${placeholder}; background-size: cover; background-position: center;" data-wiki-img="${m.name}">
            <div class="detail-header-overlay"></div>
            <div class="detail-header-content">
                <div style="display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:20px;">
                    <div>
                        <h1 class="detail-title">${m.name} ${m.localName ? '('+m.localName+')' : ''}</h1>
                        <div class="detail-subtitle">
                            <span><i data-lucide="mountain"></i> ${m.elevation} mdpl</span>
                            <span><i data-lucide="map-pin"></i> ${m.province}</span>
                            ${getDifficultyBadge(m.difficulty)}
                        </div>
                    </div>
                    <div style="display:flex; gap:15px; margin-bottom:10px; flex-wrap:wrap;">
                        <button class="btn btn-outline" style="background:rgba(255,255,255,0.1); color:white; border-color:white; backdrop-filter:blur(10px);" onclick="openVirtual3D('${m.name}', ${m.coords[0]}, ${m.coords[1]}, ${m.elevation})">
                            <i data-lucide="box"></i> 3D Virtual View
                        </button>
                        <button class="btn btn-outline" style="background:rgba(255,255,255,0.1); color:white; border-color:white; backdrop-filter:blur(10px);" onclick="shareMountain('${m.name}', ${m.elevation}, '${m.province}')">
                            <i data-lucide="share-2"></i> Share
                        </button>
                        <button class="btn btn-outline" style="background:rgba(255,255,255,0.1); color:white; border-color:white; backdrop-filter:blur(10px);" onclick="playAudioBriefing('${m.name}', ${m.elevation}, '${m.difficulty}')">
                            <i data-lucide="volume-2"></i> Voice Briefing
                        </button>
                        <button class="btn btn-primary" style="background:#dc2626; box-shadow:0 4px 15px rgba(220,38,38,0.4);" onclick="generateSOS('${m.name}')">
                            <i data-lucide="radio-tower"></i> SOS Darurat
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="container py-5 detail-content">
            <div class="main-column">
                
                <!-- A & B. IDENTITAS & RINGKASAN CEPAT -->
                <div class="detail-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                        <h3 style="margin:0;"><i data-lucide="info"></i> Identitas & Ringkasan</h3>
                        <div id="safety-score-container">${getSafetyBadgeHtml(baseSafetyScore)}</div>
                    </div>
                    
                    ${(() => {
                        const est = getTrekEstimates(m.elevation, m.difficulty, m.id);
                        return `
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px; background:var(--color-bg); padding:15px; border-radius:8px;">
                            <div>
                                <span class="info-label" style="display:block; margin-bottom:5px;">Region / Kabupaten</span>
                                <span class="info-value" style="font-weight:bold;">${m.region}</span>
                            </div>
                            <div>
                                <span class="info-label" style="display:block; margin-bottom:5px;">Kawasan Pengelola</span>
                                <span class="info-value" style="font-weight:bold;">${m.nationalPark}</span>
                            </div>
                            <div>
                                <span class="info-label" style="display:block; margin-bottom:5px;">Estimasi Jarak Tempuh</span>
                                <span class="info-value" style="font-weight:bold; color:var(--color-accent);">${est.distancePP}</span>
                            </div>
                            <div>
                                <span class="info-label" style="display:block; margin-bottom:5px;">Durasi Normal</span>
                                <span class="info-value" style="font-weight:bold;">${est.duration}</span>
                            </div>
                            <div>
                                <span class="info-label" style="display:block; margin-bottom:5px;">Status Vulkanik</span>
                                <span class="info-value" style="font-weight:bold;">${m.status}</span>
                            </div>
                            <div>
                                <span class="info-label" style="display:block; margin-bottom:5px;">Koordinat Puncak</span>
                                <span class="info-value" style="font-weight:bold;">${m.coords[0]}, ${m.coords[1]}</span>
                            </div>
                        </div>
                        `;
                    })()}
                    

                </div>

                <!-- C. DESKRIPSI -->
                <div class="detail-card">
                    <h3><i data-lucide="align-left"></i> Deskripsi & Karakteristik</h3>
                    <p style="font-size:1.05rem; line-height: 1.7;">${m.description}</p>
                </div>

                <!-- D. JALUR PENDAKIAN & GPX -->
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                        <h3 style="margin:0;"><i data-lucide="map"></i> Peta & Jalur Pendakian</h3>
                        ${m.hasGpx ? `<button class="btn btn-primary" onclick="downloadGPX('${m.id}')" style="padding:5px 15px; font-size:0.9rem;"><i data-lucide="download" style="width:16px;"></i> Download GPX</button>` : ''}
                    </div>

                    <div style="background:var(--color-bg); padding:15px; border-radius:8px; margin-bottom:15px;">
                        <strong>Jalur Resmi Populer:</strong> ${m.routes.join(', ')}
                    </div>

                    ${!m.hasGpx ? '<p class="mb-4 text-warning">Peta jalur GPX dinamis belum direkam untuk gunung ini, namun peta Topografi (Kontur) tetap tersedia di bawah.</p>' : '<p class="mb-4" style="color:var(--color-primary);"><i data-lucide="check-circle" style="width:16px;"></i> Overlay Jalur GPX Tersedia pada Peta Topografi di bawah.</p>'}
                    <div id="topo-map"></div>

                    ${m.hasGpx ? `
                    <div style="margin-top: 25px; padding: 20px; background: rgba(21, 50, 25, 0.02); border: 1px solid var(--color-border); border-radius: var(--radius-md);">
                        <h4 style="font-size: 1.1rem; margin-bottom: 12px; display: flex; align-items: center; gap: 8px;">
                            <i data-lucide="trending-up" style="color:var(--color-accent)"></i> Profil Ketinggian Jalur (GPX Data)
                        </h4>
                        <div style="height: 200px; position: relative;">
                            <canvas id="elevationChart"></canvas>
                        </div>
                    </div>
                    ` : ''}
                </div>

                <!-- KONDISI & REVIEW -->
                <div class="detail-card" id="reviews-section">
                    <h3><i data-lucide="message-square"></i> Review & Kondisi Jalur Terkini</h3>
                    <p style="font-size:0.9rem; color:var(--color-text-light); margin-bottom:15px;">Bagikan info terbaru, ketersediaan air, maupun dokumentasi pengalamanmu kepada pendaki lain!</p>
                    
                    <form onsubmit="submitComment(event, '${m.id}')" style="margin-bottom:30px; background:var(--color-bg); padding:20px; border-radius:8px; border:1px solid var(--color-border);">
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px;">
                            <input type="text" id="comment-name" placeholder="Nama / Kelompok Pendaki" required style="padding:10px; border-radius:4px; border:1px solid #ccc; font-family:var(--font-body);">
                            <select id="comment-rating" style="padding:10px; border-radius:4px; border:1px solid #ccc; font-family:var(--font-body);">
                                <option value="5">⭐⭐⭐⭐⭐ 5/5 - Sangat Merekomendasikan (Jalur Aman)</option>
                                <option value="4">⭐⭐⭐⭐ 4/5 - Bagus</option>
                                <option value="3">⭐⭐⭐ 3/5 - Cukup / Standar</option>
                                <option value="2">⭐⭐ 2/5 - Kurang (Banyak Sampah/Sulit Air)</option>
                                <option value="1">⭐ 1/5 - Bahaya (Longsor/Badai)</option>
                            </select>
                        </div>
                        <div style="margin-bottom:15px;">
                            <textarea id="comment-text" placeholder="Ceritakan pengalamanmu... Bagaimana kondisi trek saat ini? Apakah basecamp ramah? Air mudah didapat?" required style="width:100%; padding:10px; border-radius:4px; border:1px solid #ccc; height:100px; font-family:var(--font-body);"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary"><i data-lucide="send"></i> Posting Laporan Kondisi</button>
                    </form>

                    <div id="comments-list">
                        ${savedComments.length === 0 ? '<p style="color:var(--color-text-light); text-align:center; padding:20px 0;">Belum ada review. Jadilah pendaki pertama yang meninggalkan ulasan untuk gunung ini!</p>' : savedComments.map(c => 
                            '<div style="border-bottom:1px solid var(--color-border); padding:15px 0; margin-bottom:10px;">' +
                                '<div style="display:flex; justify-content:space-between; margin-bottom:5px;">' +
                                    '<strong style="font-size:1.1rem;">' + c.name + '</strong>' +
                                    '<span style="color:#ffc107; font-size:1.1rem;">' + '⭐'.repeat(c.rating) + '</span>' +
                                '</div>' +
                                '<div style="font-size:0.8rem; color:var(--color-text-light); margin-bottom:10px;">' + c.date + '</div>' +
                                '<p style="font-size:0.95rem; opacity:0.9; line-height:1.5;">' + c.text + '</p>' +
                            '</div>'
                        ).join('')}
                    </div>
                </div>

            </div>

            <div class="side-column">
                
                <!-- STATUS PENDAKIAN -->
                <div class="detail-card">
                    <h3><i data-lucide="activity"></i> Status Pendakian</h3>
                    <div style="margin-top:10px; margin-bottom:20px;">
                        ${getStatusBadge(m.status)}
                    </div>
                    <ul class="info-list" style="font-size: 0.9rem;">
                        <li><span class="info-label">Update Terakhir:</span> <span class="info-value">${m.lastUpdated}</span></li>
                        ${m.status.includes('DITUTUP') ? '<li style="color:#dc3545; font-weight:bold;">JALUR DITUTUP. Dilarang melakukan pendakian dalam bentuk apapun demi keselamatan.</li>' : ''}
                    </ul>
                </div>

                <!-- LIVE WEATHER -->
                <div class="detail-card">
                    <h3><i data-lucide="cloud-lightning"></i> Info Cuaca Puncak</h3>
                    <div id="weather-container">
                        <div style="text-align:center; padding:20px; color:var(--color-text-light);">
                            <i data-lucide="loader" class="spin"></i> Menarik data satelit...
                        </div>
                    </div>
                </div>

                <!-- SATELLITE EXPLORE SEGMENTS -->
                <div class="detail-card">
                    <h3><i data-lucide="map"></i> Data Jalur Pendakian</h3>
                    <p style="font-size:0.85rem; color:var(--color-text-light); margin-bottom:15px;">Pindai data satelit untuk menemukan rute pendakian terpopuler dan hitung estimasi waktu tempuh secara akurat.</p>
                    <button class="btn btn-outline" style="width:100%; display:flex; justify-content:center; gap:8px;" onclick="window.fetchStravaSegments('${m.id}')">
                        <i data-lucide="search"></i> Pindai Jalur
                    </button>
                    <div id="strava-container" style="margin-top:15px; display:none; background:var(--color-bg); padding:10px; border-radius:8px; border:1px solid var(--color-border);">
                    </div>
                </div>

                <!-- KALKULATOR KALORI & AIR -->
                <div class="detail-card">
                    <h3><i data-lucide="droplet"></i> Kebutuhan Logistik Personal</h3>
                    <p style="font-size:0.85rem; color:var(--color-text-light); margin-bottom:15px;">Hitung air dan kalori berdasarkan ilmu pendakian medis.</p>
                    <div style="display:flex; gap:10px; margin-bottom:15px;">
                        <input type="number" id="user-weight" placeholder="Berat badan (kg)" class="search-bar" style="width:100%;" value="65">
                        <button class="btn btn-primary" onclick="calculateCalorieWater(${m.elevation}, ${m.difficulty})" style="padding:10px;">Hitung</button>
                    </div>
                    <div id="calorie-result" style="display:none; background:var(--color-bg); padding:15px; border-radius:8px; border:1px solid var(--color-border);"></div>
                </div>

                <!-- INFO REGISTRASI / SIMAKSI ONLINE -->
                <div class="detail-card">
                    <h3><i data-lucide="clipboard-check"></i> Registrasi Pendakian</h3>
                    <div style="background: rgba(21, 50, 25, 0.05); padding: 15px; border-radius: 8px; border: 1px solid var(--color-border); margin-top: 15px;">
                        <div style="font-size:0.9rem; margin-bottom:10px; color:var(--color-text-light);">
                            Pastikan mendaftar dan registrasi sebelum mendaki untuk keselamatan dan kenyamanan.
                        </div>
                        <a href="${contactInfo.simaksiUrl ? contactInfo.simaksiUrl : '#'}" target="${contactInfo.simaksiUrl ? '_blank' : '_self'}" class="btn ${contactInfo.simaksiUrl ? 'btn-primary' : 'btn-outline'}" style="width:100%; display:flex; justify-content:center; padding:8px; font-size:0.9rem;">
                            <i data-lucide="${contactInfo.simaksiUrl ? 'globe' : 'map-pin'}"></i> ${contactInfo.simaksiText}
                        </a>
                    </div>
                </div>

                <!-- PARAMETER FISIOLOGI & MEDIS (AMS) -->
                <div class="detail-card">
                    <h3><i data-lucide="heart-pulse"></i> Parameter Fisiologi & Medis</h3>
                    <ul class="info-list" style="font-size: 0.9rem;">
                        <li>
                            <span class="info-label">Kadar Oksigen Efektif:</span>
                            <span class="info-value" style="color: ${m.elevation >= 3000 ? 'var(--color-danger)' : 'inherit'};">${(20.9 * Math.exp(-m.elevation / 7400)).toFixed(1)}% (Normal 21%)</span>
                        </li>
                        <li>
                            <span class="info-label">Titik Didih Air:</span>
                            <span class="info-value">${(100 - (m.elevation / 300)).toFixed(1)}°C (Normal 100°C)</span>
                        </li>
                        <li>
                            <span class="info-label">Risiko AMS:</span>
                            <span class="info-value" style="font-weight: bold; color: ${m.elevation >= 3000 ? 'var(--color-danger)' : (m.elevation >= 2000 ? 'var(--color-warning)' : 'var(--color-success)')};">
                                ${m.elevation >= 3000 ? 'Sangat Tinggi' : (m.elevation >= 2000 ? 'Sedang' : 'Rendah')}
                            </span>
                        </li>
                        <li>
                            <span class="info-label">Target Hidrasi:</span>
                            <span class="info-value">${m.elevation >= 3000 ? '3.5' : (m.elevation >= 2000 ? '3.0' : '2.5')} L / hari</span>
                        </li>
                    </ul>
                    <div style="margin-top: 15px; font-size: 0.85rem; padding: 12px; background: rgba(21, 50, 25, 0.05); border-radius: 8px; border-left: 3px solid var(--color-primary);">
                        <strong>Saran Medis:</strong> ${m.elevation >= 3000 ? 'Wajib aklimatisasi 1 hari di basecamp / pos tengah. Bawa tabung oksigen portabel.' : (m.elevation >= 2000 ? 'Istirahat teratur setiap kenaikan 500m. Jangan langsung tidur setelah sampai di camp site.' : 'Lakukan pendakian dengan kecepatan konstan & hidrasi cukup.')}
                    </div>
                </div>

                <!-- DOKUMEN & SURAT IZIN -->
                <div class="detail-card">
                    <h3><i data-lucide="file-text"></i> Dokumen Administrasi</h3>
                    <div style="background: rgba(255, 193, 7, 0.1); padding: 15px; border-radius: 8px; border: 1px solid rgba(255, 193, 7, 0.3); margin-bottom: 15px; margin-top: 15px;">
                        <div style="font-weight:bold; margin-bottom:5px; color:#b45309; display:flex; align-items:center; gap:6px;">
                            <i data-lucide="info" style="width:16px; height:16px;"></i> Info Surat Keterangan Sehat
                        </div>
                        <div style="font-size:0.9rem; color:var(--color-text-light); line-height: 1.5;">
                            Surat Keterangan Sehat <b>wajib diurus langsung di Puskesmas, Klinik, atau Rumah Sakit</b>. Sistem aplikasi tidak dapat membuat/mengeluarkan surat sehat secara online karena membutuhkan pemeriksaan fisik dokter.
                        </div>
                    </div>
                    <div style="font-size:0.85rem; color:var(--color-text-light); margin-bottom:10px;">
                        Gunakan tombol di bawah untuk mengunduh otomatis <b>Template Surat Pernyataan / Izin Orang Tua</b> (Syarat wajib simaksi):
                    </div>
                    <button class="btn btn-outline" style="width:100%; display:flex; justify-content:center; gap:8px;" onclick="window.downloadSuratIzin('${m.name}')">
                        <i data-lucide="file-down"></i> Buat & Download Surat Izin
                    </button>
                </div>

                <!-- LOGISTIK / PERLENGKAPAN -->
                <div class="detail-card">
                    <h3><i data-lucide="backpack"></i> Persiapan Ekstra</h3>
                    <ul class="info-list" style="font-size: 0.9rem; margin-bottom:20px;">
                        <li>Pastikan membawa perlengkapan standar pendakian yang mumpuni.</li>
                        <li>Cek informasi pembukaan jalur ke pihak pengelola sebelum berangkat.</li>
                    </ul>
                    <a href="#planner" class="btn btn-primary" style="display:flex; text-align:center; width: 100%; margin-bottom:10px;"><i data-lucide="calculator"></i> Kalkulator Biaya Pendakian</a>
                    <button class="btn btn-outline" style="display:flex; text-align:center; width: 100%; background:var(--color-bg);" onclick="startAICompanion()"><i data-lucide="bot"></i> Tanya AI Pendaki Assistant</button>
                </div>
            </div>
        </div>

        <!-- AI Assistant Modal -->
        <div id="ai-modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.6); z-index:9999; align-items:center; justify-content:center; backdrop-filter:blur(5px);">
            <div style="background:var(--color-card-bg); width:90%; max-width:500px; border-radius:var(--radius-lg); padding:30px; box-shadow:var(--shadow-premium); border:1px solid var(--color-border); position:relative;">
                <button onclick="document.getElementById('ai-modal').style.display='none'" style="position:absolute; right:20px; top:20px; background:none; border:none; cursor:pointer; color:var(--color-text);"><i data-lucide="x"></i></button>
                <div style="display:flex; align-items:center; gap:15px; margin-bottom:20px;">
                    <div style="width:50px; height:50px; border-radius:50%; background:var(--color-primary); color:white; display:flex; align-items:center; justify-content:center;">
                        <i data-lucide="bot" style="width:24px; height:24px;"></i>
                    </div>
                    <div>
                        <h3 style="margin:0; color:var(--color-text);">Puncak AI Assistant</h3>
                        <span style="font-size:0.8rem; color:var(--color-success);">Online</span>
                    </div>
                </div>
                <div id="ai-chat-box" style="height:300px; overflow-y:auto; background:var(--color-bg); border-radius:8px; padding:15px; margin-bottom:15px; font-size:0.95rem; border:1px solid var(--color-border); display:flex; flex-direction:column; gap:12px;">
                    <div style="align-self:flex-start; background:var(--color-bg); padding:12px 18px; border-radius:15px 15px 15px 0; border:1px solid var(--color-border); box-shadow:0 4px 6px rgba(0,0,0,0.05); max-width:85%; line-height:1.5;">
                        Halo! Saya AI assistant pakar <b>Gunung ${m.name}</b>. Apa yang ingin kamu tanyakan mengenai info rute <b>${m.routes[0]}</b>, kondisi cuaca ekstrem di ketinggian ${m.elevation} mdpl, atau mungkin syarat simaksi di ${m.nationalPark}?
                    </div>
                </div>
                <div style="display:flex; gap:10px;">
                    <input type="text" id="ai-input" placeholder="Tanya sesuatu..." onkeypress="if(event.key==='Enter')sendAIMessage()" style="flex:1; padding:10px; border-radius:var(--radius-full); border:1px solid var(--color-border); background:var(--color-bg); color:var(--color-text);">
                    <button class="btn btn-primary" onclick="sendAIMessage()" style="border-radius:var(--radius-full); width:45px; height:45px; padding:0; display:flex; align-items:center; justify-content:center;"><i data-lucide="send" style="width:18px;"></i></button>
                </div>
            </div>
        </div>

        <!-- 3D Panorama Modal -->
        <div id="panorama-modal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.8); z-index:9999; align-items:center; justify-content:center; backdrop-filter:blur(5px);">
            <div id="panorama-container" style="width:100%; max-width:500px; padding:20px;">
                <!-- Akan diisi oleh JS -->
            </div>
        </div>
    `;
    appRoot.innerHTML = html;

    // initTopoMap handles both rendering the Topo layer and loading GPX overlay if hasGpx is true
    initTopoMap(m);
    
    // fetchWeather updates #weather-container and live safety score based on satellite data
    fetchWeather(m, baseSafetyScore);
    
    lucide.createIcons();

    if (m.hasGpx) {
        setTimeout(() => {
            initElevationChart(m.id);
        }, 300);
    }
}

window.downloadSuratIzin = function(mountainName) {
    const template = `SURAT PERNYATAAN IZIN ORANG TUA / WALI

Yang bertanda tangan di bawah ini:
Nama Lengkap      : .......................................................
Alamat            : .......................................................
No. Telepon / HP  : .......................................................
Hubungan Keluarga : (Orang Tua / Wali) *Coret yang tidak perlu

Dengan ini memberikan izin kepada anak / anggota keluarga kami:
Nama Lengkap      : .......................................................
Tempat/Tgl Lahir  : .......................................................
Alamat            : .......................................................

Untuk mengikuti kegiatan pendakian di Gunung ${mountainName} yang akan dilaksanakan pada tanggal ........ s/d ........
Kami menyatakan bahwa anak/anggota keluarga kami dalam kondisi SEHAT secara fisik dan mental.
Segala risiko yang terjadi selama pendakian merupakan tanggung jawab kami selaku orang tua/wali dan peserta.

Demikian surat pernyataan izin ini dibuat dengan sebenar-benarnya tanpa ada paksaan dari pihak manapun untuk dipergunakan sebagaimana mestinya.

..........., ....................... 20..
Yang membuat pernyataan,
(Orang Tua / Wali)



(.......................................)
Nama Jelas & Tanda Tangan
`;
    const blob = new Blob([template], {type: 'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    document.body.appendChild(a);
    a.style = 'display: none';
    a.href = url;
    a.download = `Surat_Izin_Pendakian_${mountainName.replace(/\\s+/g, '_')}.txt`;
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    alert('Template Surat Izin berhasil diunduh. Jangan lupa lampirkan Surat Keterangan Sehat dari Klinik/Puskesmas ya!');
};

window.downloadGPX = function(id) {
    if(typeof gpxData !== 'undefined' && gpxData[id]) {
        const blob = new Blob([gpxData[id]], {type: 'application/gpx+xml'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        document.body.appendChild(a);
        a.style = 'display: none';
        a.href = url;
        a.download = `Track-${id}.gpx`;
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } else {
        alert('Maaf, file GPX untuk gunung ini belum direkam/tidak tersedia.');
    }
}

window.submitComment = function(e, mountainId) {
    e.preventDefault();
    const name = document.getElementById('comment-name').value;
    const rating = document.getElementById('comment-rating').value;
    const text = document.getElementById('comment-text').value;
    
    const comments = JSON.parse(localStorage.getItem('comments_' + mountainId)) || [];
    comments.unshift({
        name,
        rating: parseInt(rating),
        text,
        date: new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute:'2-digit' })
    });
    
    localStorage.setItem('comments_' + mountainId, JSON.stringify(comments));
    
    renderMountainDetail(mountainId);
    
    setTimeout(() => {
        document.getElementById('reviews-section').scrollIntoView({behavior: 'smooth'});
        loadWikiImages(); 
    }, 100);
}

window.openVirtual3D = function(mountainName, lat, lng, elevation) {
    // Magic URL Google Earth Web untuk langsung terjun ke lokasi dengan tilt 70 derajat (3D view)
    const earthUrl = `https://earth.google.com/web/search/${encodeURIComponent('Gunung ' + mountainName)}/@${lat},${lng},${elevation}a,3000d,35y,0h,70t,0r`;
    
    document.getElementById('panorama-container').innerHTML = `
        <div style="background:#1a1a1a; color:white; padding:35px 25px; border-radius:16px; text-align:center; box-shadow:0 15px 35px rgba(0,0,0,0.5); border:1px solid rgba(255,255,255,0.1); position:relative;">
            <button onclick="closeVirtual3D()" style="position:absolute; right:15px; top:15px; background:transparent; border:none; color:rgba(255,255,255,0.5); cursor:pointer;"><i data-lucide="x" style="width:24px; height:24px;"></i></button>
            <i data-lucide="globe-2" style="width:64px; height:64px; margin-bottom:20px; color:var(--color-accent);"></i>
            <h3 style="font-size:1.5rem; margin-bottom:12px;">Google Earth 3D API</h3>
            <p style="font-size:0.95rem; line-height:1.6; color:rgba(255,255,255,0.7); margin-bottom:25px;">
                Browser lokal memblokir akses render 3D (Black Screen). Sebagai gantinya, sistem akan langsung membuka <b>Google Earth</b> di titik puncak <b>Gunung ${mountainName}</b> dengan format 3D.
            </p>
            <a href="${earthUrl}" target="_blank" class="btn btn-primary" style="display:inline-flex; align-items:center; gap:8px; padding:12px 25px; font-size:1.05rem;" onclick="closeVirtual3D()">
                <i data-lucide="external-link"></i> Buka Google Earth 3D
            </a>
        </div>
    `;
    
    document.getElementById('panorama-modal').style.display = 'flex';
    lucide.createIcons();
}

window.closeVirtual3D = function() {
    document.getElementById('panorama-modal').style.display = 'none';
}

window.generateSOS = function(mountainName) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const msg = `[DARURAT] Saya membutuhkan bantuan evakuasi SAR di Gunung ${mountainName}. Lokasi GPS terakhir: https://maps.google.com/?q=${lat},${lng}. Mohon segera dikirimkan tim bantuan!`;
            const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(msg)}`;
            window.open(whatsappUrl, '_blank');
        }, function(error) {
            alert('Gagal mendapatkan lokasi GPS. Pesan darurat tetap akan dibuat tanpa koordinat presisi.');
            const msg = `[DARURAT] Saya membutuhkan bantuan evakuasi SAR di Gunung ${mountainName}. Lokasi koordinat belum diketahui. Mohon segera dikirimkan tim bantuan!`;
            const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(msg)}`;
            window.open(whatsappUrl, '_blank');
        });
    } else {
        alert("Geolocation tidak didukung oleh browser ini.");
    }
}

window.startAICompanion = function() {
    document.getElementById('ai-modal').style.display = 'flex';
}

window.sendAIMessage = async function() {
    const input = document.getElementById('ai-input');
    const chatBox = document.getElementById('ai-chat-box');
    const text = input.value.trim();
    
    if(!text) return;
    
    // Cetak balon chat user
    const userDiv = document.createElement('div');
    userDiv.style.cssText = 'align-self:flex-end; background:var(--color-primary); color:white; padding:12px 18px; border-radius:15px 15px 0 15px; max-width:85%; line-height:1.4; box-shadow:0 4px 6px rgba(230, 95, 18, 0.2);';
    userDiv.textContent = text;
    chatBox.appendChild(userDiv);
    
    input.value = '';
    
    // Tampilkan animasi typing
    const typingDiv = document.createElement('div');
    typingDiv.id = "ai-typing";
    typingDiv.style.cssText = 'align-self:flex-start; background:var(--color-bg); padding:10px 15px; border-radius:15px 15px 15px 0; max-width:85%; color:var(--color-text-light); font-style:italic; border:1px solid var(--color-border); display:flex; align-items:center; gap:8px;';
    typingDiv.innerHTML = '<i data-lucide="loader" style="animation: spin 1s linear infinite; width:16px;"></i> Menganalisa pertanyaan (LLM Engine)...';
    chatBox.appendChild(typingDiv);
    lucide.createIcons();
    chatBox.scrollTop = chatBox.scrollHeight;
    
    const m = window.currentMountain;
    if (!m) return; // Failsafe
    
    try {
        // Konteks AI Khusus Gunung (System Prompt)
        const systemPrompt = `Kamu adalah "Puncak AI", asisten pakar pendakian dari PuncakNusantara. Kamu sedang memandu pendaki tentang Gunung ${m.name} yang memiliki ketinggian ${m.elevation} mdpl. Lokasi gunung ini ada di wilayah ${m.region}, ${m.province}. Gunung ini dikelola oleh ${m.nationalPark}. Tingkat kesulitan pendakiannya adalah Level ${m.difficulty} dari 4. Jalur resminya meliputi: ${m.routes.join(', ')}. Status saat ini: ${m.status}. 
        Tugas kamu: Jawablah pertanyaan user dengan seakurat mungkin, sangat informatif, dan profesional layaknya guide ahli. Gunakan bahasa Indonesia yang santai tapi sopan. Jika tidak tahu, berikan saran logis. Jika user bertanya tentang hal di luar pendakian, ingatkan user dengan sopan bahwa kamu adalah pakar gunung. Ingat: Selalu rujuk kembali ke konteks Gunung ${m.name} jika relevan.`;

        // Menggunakan layanan open gratis (Pollinations.ai via Anonymous GET) - Tanpa API Key!
        const fullPrompt = `${systemPrompt}\n\nPertanyaan dari user: ${text}\n\nTolong dijawab:`;
        const url = `https://text.pollinations.ai/${encodeURIComponent(fullPrompt)}`;

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error("API Network Error");
        }
        
        let replyText = await response.text();

        const typingEl = document.getElementById('ai-typing');
        if(typingEl) typingEl.remove();

        const aiDiv = document.createElement('div');
        aiDiv.style.cssText = 'align-self:flex-start; background:var(--color-bg); padding:14px 18px; border-radius:15px 15px 15px 0; max-width:85%; border:1px solid var(--color-border); box-shadow:0 4px 6px rgba(0,0,0,0.05); line-height:1.6; font-size:0.95rem;';
        
        // Parsing markdown sederhana (Bold/Strong/Breaks)
        replyText = replyText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        replyText = replyText.replace(/\*(.*?)\*/g, '<i>$1</i>');
        replyText = replyText.replace(/\n/g, '<br>');
        
        aiDiv.innerHTML = replyText;
        chatBox.appendChild(aiDiv);
        chatBox.scrollTop = chatBox.scrollHeight;

    } catch (err) {
        console.error("AI API Error:", err);
        // --- FALLBACK JIKA API OFFLINE / GAGAL ---
        const typingEl = document.getElementById('ai-typing');
        if(typingEl) typingEl.remove();

        const aiDiv = document.createElement('div');
        aiDiv.style.cssText = 'align-self:flex-start; background:var(--color-bg); padding:14px 18px; border-radius:15px 15px 15px 0; max-width:85%; border:1px solid var(--color-border); box-shadow:0 4px 6px rgba(0,0,0,0.05); line-height:1.6; font-size:0.95rem;';
        
        const lowerText = text.toLowerCase();
        let reply = "";
        
        if (lowerText.includes('rute') || lowerText.includes('jalur') || lowerText.includes('track')) {
            reply = `Gunung **${m.name}** memiliki beberapa jalur resmi: **${m.routes.join(', ')}**. Tingkat kesulitan **Level ${m.difficulty}**.`;
        } 
        else if (lowerText.includes('ketinggian') || lowerText.includes('mdpl')) {
            reply = `Puncak Gunung ${m.name} berada pada ketinggian **${m.elevation} mdpl**. Risiko AMS berstatus **${m.elevation >= 3000 ? 'Sangat Tinggi' : 'Sedang'}**.`;
        }
        else {
            reply = `*(Server AI sedang sibuk, beralih ke mode luring)*<br>Mengenai "${text}", AI luring saat ini difokuskan pada topologi **Gunung ${m.name}**. Silakan cek segmen *Identitas & Deskripsi* di layar utama.`;
        }
        
        reply = reply.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        reply = reply.replace(/\*(.*?)\*/g, '<i>$1</i>');
        
        aiDiv.innerHTML = reply;
        chatBox.appendChild(aiDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

window.initElevationChart = function(id) {
    if(!gpxData || !gpxData[id]) return;
    
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(gpxData[id], "text/xml");
    const trkpts = xmlDoc.getElementsByTagName("trkpt");
    
    let elevations = [];
    let labels = [];
    for(let i=0; i<trkpts.length; i++) {
        let ele = trkpts[i].getElementsByTagName("ele")[0];
        if(ele) {
            elevations.push(parseFloat(ele.textContent));
            labels.push('Titik ' + (i+1));
        }
    }
    
    if(elevations.length === 0) return;

    const ctx = document.getElementById('elevationChart');
    if(!ctx) return;
    
    if(window.myElevationChart) {
        window.myElevationChart.destroy();
    }
    
    window.myElevationChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Ketinggian (mdpl)',
                data: elevations,
                borderColor: '#e65f12',
                backgroundColor: 'rgba(230, 95, 18, 0.2)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { display: false },
                y: { 
                    beginAtZero: false,
                    title: { display: true, text: 'mdpl' }
                }
            }
        }
    });
}

function initMap(m) {
    const map = L.map('map').setView(m.coords, 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
    }).addTo(map);

    L.marker(m.coords).addTo(map).bindPopup(`<b>Puncak ${m.name}</b><br>${m.elevation} mdpl`).openPopup();

    if(m.hasGpx && typeof gpxData !== 'undefined' && gpxData[m.id]) {
        new L.GPX(gpxData[m.id], {
            async: true,
            marker_options: {
                startIconUrl: 'https://unpkg.com/leaflet-gpx/pin-icon-start.png',
                endIconUrl: 'https://unpkg.com/leaflet-gpx/pin-icon-end.png',
                shadowUrl: 'https://unpkg.com/leaflet-gpx/pin-shadow.png'
            },
            polyline_options: { color: '#d95c14', weight: 5, opacity: 0.8 }
        }).on('loaded', function(e) {
            map.fitBounds(e.target.getBounds());
        }).addTo(map);
    }
}

async function fetchWeather(m, baseSafetyScore) {
    const container = document.getElementById('weather-container');
    const safetyContainer = document.getElementById('safety-score-container');
    try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${m.coords[0]}&longitude=${m.coords[1]}&current=temperature_2m,wind_speed_10m,precipitation&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=Asia%2FJakarta`;
        const res = await fetch(url);
        const data = await res.json();
        const current = data.current;
        const daily = data.daily;

        let weatherScoreMod = 0;
        let safetyHtml = '';
        if(current.wind_speed_10m > 40 || current.precipitation > 5) {
            weatherScoreMod = -4;
            safetyHtml = '<div class="safety-indicator safety-danger">HINDARI PENDAKIAN (Cuaca Buruk/Badai)</div>';
        } else if (current.wind_speed_10m > 20 || current.precipitation > 1) {
            weatherScoreMod = -2;
            safetyHtml = '<div class="safety-indicator safety-warning">WASPADAI (Hujan/Angin Kencang)</div>';
        } else {
            weatherScoreMod = 1;
            safetyHtml = '<div class="safety-indicator safety-safe">AMAN (Cuaca Cerah/Mendukung)</div>';
        }

        // Live update safety score badge based on weather
        const newScore = getSafetyScore(m, weatherScoreMod);
        if(safetyContainer) {
            safetyContainer.innerHTML = getSafetyBadgeHtml(newScore);
        }

        let forecastHtml = '<div class="weather-forecast">';
        for(let i=0; i<3; i++) {
            const date = new Date(daily.time[i]);
            forecastHtml += `
                <div class="weather-day">
                    <div class="date">${date.toLocaleDateString('id-ID', {weekday:'short'})}</div>
                    <i data-lucide="cloud"></i>
                    <div class="temp">${Math.round(daily.temperature_2m_max[i])}&deg;</div>
                </div>
            `;
        }
        forecastHtml += '</div>';

        container.innerHTML = `
            ${safetyHtml}
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; background:var(--color-bg); padding:15px; border-radius:8px;">
                <div>
                    <div style="font-size:2rem; font-weight:bold;">${Math.round(current.temperature_2m)}&deg;C</div>
                    <div style="color:var(--color-text-light); font-size:0.8rem;">Suhu Elevasi Gunung</div>
                </div>
                <div style="text-align:right; font-size:0.9rem;">
                    <div><i data-lucide="wind" style="width:16px; height:16px; vertical-align: middle;"></i> ${current.wind_speed_10m} km/h</div>
                    <div><i data-lucide="cloud-rain" style="width:16px; height:16px; vertical-align: middle;"></i> ${current.precipitation} mm</div>
                </div>
            </div>
            ${forecastHtml}
            <p style="font-size:0.7rem; color:var(--color-text-light); margin-top:10px; text-align:center;">Data satelit Open-Meteo.</p>
        `;
        lucide.createIcons();
    } catch (e) {
        container.innerHTML = '<p>Gagal memuat data cuaca satelit.</p>';
    }
}

// ================= STRAVA API INTEGRATION =================
async function getStravaAccessToken() {
    const clientId = '250762';
    const clientSecret = '51c08e2e5b71bb0c215c01ed977f607320da15b6';
    let refreshToken = localStorage.getItem('strava_refresh_token') || 'fa8048ac61815c1102e97de5158e43a473be5751';
    let expiresAt = localStorage.getItem('strava_expires_at');
    let accessToken = localStorage.getItem('strava_access_token');
    
    // Check if token is still valid (add 5 min buffer)
    if (accessToken && expiresAt && (Date.now() / 1000) < (parseInt(expiresAt) - 300)) {
        return accessToken;
    }
    
    try {
        const res = await fetch('https://www.strava.com/api/v3/oauth/token', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                client_id: clientId,
                client_secret: clientSecret,
                grant_type: 'refresh_token',
                refresh_token: refreshToken
            })
        });
        const data = await res.json();
        if(data.access_token) {
            localStorage.setItem('strava_access_token', data.access_token);
            localStorage.setItem('strava_refresh_token', data.refresh_token);
            localStorage.setItem('strava_expires_at', data.expires_at);
            return data.access_token;
        }
    } catch(e) { console.error("Strava Auth Error:", e); }
    return null;
}

// Decode Google Polyline format (from Strava) to LatLng array for Leaflet
function decodePolyline(str, precision) {
    let index = 0, lat = 0, lng = 0, coordinates = [], shift = 0, result = 0, byte = null, latitude_change, longitude_change, factor = Math.pow(10, Number.isInteger(precision) ? precision : 5);
    while (index < str.length) {
        byte = null; shift = 0; result = 0;
        do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
        latitude_change = ((result & 1) ? ~(result >> 1) : (result >> 1));
        shift = result = 0;
        do { byte = str.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20);
        longitude_change = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += latitude_change; lng += longitude_change;
        coordinates.push([lat / factor, lng / factor]);
    }
    return coordinates;
}

window.fetchStravaSegments = async function(mountainId) {
    const container = document.getElementById('strava-container');
    container.style.display = 'block';
    container.innerHTML = '<div style="text-align:center; padding:10px;"><i data-lucide="loader" class="spin"></i> Sedang mencari data trek...</div>';
    lucide.createIcons();
    
    const m = mountains.find(x => x.id === mountainId);
    if (!m) return;

    const token = await getStravaAccessToken();
    if (!token) {
        container.innerHTML = '<div style="color:var(--color-danger); text-align:center;">Sistem sedang sibuk, gagal memindai rute.</div>';
        return;
    }

    // Bounding box sekitar 5-10km dari titik pusat gunung
    const lat = m.coords[0];
    const lng = m.coords[1];
    const bounds = `${lat - 0.05},${lng - 0.05},${lat + 0.05},${lng + 0.05}`;

    try {
        const res = await fetch(`https://www.strava.com/api/v3/segments/explore?bounds=${bounds}&activity_type=running`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const data = await res.json();
        
        if (data.segments && data.segments.length > 0) {
            // Sort by climb category and elevation to get the most "mountainous" tracks
            // Mengambil 1 trek saja agar menjadi "Track Record Tunggal"
            let bestSegment = data.segments.sort((a,b) => b.elev_difference - a.elev_difference)[0];
            
            const distKm = (bestSegment.distance / 1000).toFixed(2);
            
            // Naismith's Rule for Hiking/Trekking
            const baseTimeHours = (bestSegment.distance / 1000) / 3.0;
            const elevTimeHours = bestSegment.elev_difference > 0 ? (bestSegment.elev_difference / 300) : 0;
            const totalHours = baseTimeHours + elevTimeHours;
            
            const jam = Math.floor(totalHours);
            const menit = Math.round((totalHours - jam) * 60);
            let estTimeText = '';
            if(jam > 0) estTimeText += `${jam} Jam `;
            if(menit > 0) estTimeText += `${menit} Menit`;
            if(jam === 0 && menit === 0) estTimeText = '< 1 Menit';

            let html = `
                <div style="background:var(--color-card-bg); border:2px solid var(--color-primary); padding:15px; border-radius:8px; position:relative; overflow:hidden;">
                    <div style="position:absolute; top:0; right:0; background:var(--color-primary); color:white; font-size:0.7rem; font-weight:bold; padding:4px 10px; border-bottom-left-radius:8px;">Satelit Terverifikasi</div>
                    <div style="font-weight:900; color:var(--color-primary); margin-bottom:10px; font-size:1.15rem; padding-right:70px;">Rute Utama ${m.name}</div>
                    
                    <div style="background:rgba(230,95,18,0.1); padding:10px; border-radius:6px; margin-bottom:12px; display:flex; align-items:center; gap:12px; border:1px solid rgba(230,95,18,0.3);">
                        <i data-lucide="clock" style="color:var(--color-accent); width:24px; height:24px;"></i>
                        <div>
                            <div style="font-size:0.8rem; color:var(--color-text-light);">Estimasi Waktu Hiking Santai</div>
                            <div style="font-weight:bold; color:var(--color-accent); font-size:1.2rem;">${estTimeText}</div>
                        </div>
                    </div>

                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; font-size:0.9rem; color:var(--color-text-light); background:var(--color-bg); padding:12px; border-radius:6px; border:1px solid var(--color-border);">
                        <div style="display:flex; align-items:center; gap:6px;"><i data-lucide="route" style="width:16px;"></i> Jarak:<br><b>${distKm} km</b></div>
                        <div style="display:flex; align-items:center; gap:6px;"><i data-lucide="trending-up" style="width:16px;"></i> Elevasi:<br><b>+${bestSegment.elev_difference} m</b></div>
                        <div style="display:flex; align-items:center; gap:6px;"><i data-lucide="activity" style="width:16px;"></i> Kemiringan:<br><b>${bestSegment.avg_grade}%</b></div>
                        <div style="display:flex; align-items:center; gap:6px;"><i data-lucide="bar-chart" style="width:16px;"></i> Kategori:<br><b>${bestSegment.climb_category_desc || 'Tanjakan'}</b></div>
                    </div>
                    
                    <button class="btn btn-primary" style="width:100%; padding:10px; font-size:1rem; font-weight:bold; margin-top:15px; display:flex; justify-content:center; gap:8px;" onclick="window.plotStravaRoute('${bestSegment.points}')">
                        <i data-lucide="map-pin" style="width:18px;"></i> Lihat Jalur di Peta
                    </button>
                </div>
            `;
            container.innerHTML = html;
            lucide.createIcons();
        } else {
            container.innerHTML = '<div style="text-align:center; font-size:0.9rem; color:var(--color-text-light);">Belum ada data rekaman trek untuk area ini.</div>';
        }
    } catch (err) {
        console.error(err);
        container.innerHTML = '<div style="color:var(--color-danger); text-align:center;">Gagal mengambil data satelit.</div>';
    }
}

window.plotStravaRoute = function(polylineStr) {
    if (!window.currentLeafletMap) {
        alert("Peta belum dimuat sepenuhnya.");
        return;
    }
    
    const coords = decodePolyline(polylineStr, 5);
    
    // Clear previous Strava layers if any
    if (window.currentStravaLayer) {
        window.currentLeafletMap.removeLayer(window.currentStravaLayer);
    }
    
    window.currentStravaLayer = L.polyline(coords, {
        color: '#fc4c02', // Strava Orange
        weight: 6,
        opacity: 0.8,
        dashArray: '10, 10',
        lineJoin: 'round'
    }).addTo(window.currentLeafletMap);
    
    window.currentLeafletMap.fitBounds(window.currentStravaLayer.getBounds());
    
    // Add start/end markers
    const start = coords[0];
    const end = coords[coords.length - 1];
    
    L.circleMarker(start, {radius: 6, color: '#fc4c02', fillColor: 'white', fillOpacity: 1}).addTo(window.currentLeafletMap).bindPopup('Start Segmen Strava');
    L.circleMarker(end, {radius: 6, color: '#fc4c02', fillColor: '#fc4c02', fillOpacity: 1}).addTo(window.currentLeafletMap).bindPopup('End Segmen Strava');
    
    // Scroll to map
    document.getElementById('topo-map').scrollIntoView({ behavior: 'smooth', block: 'center' });

    // Add Action Buttons for 3D Flyover & Critical Point
    let actionContainer = document.getElementById('map-actions');
    if (!actionContainer) {
        actionContainer = document.createElement('div');
        actionContainer.id = 'map-actions';
        actionContainer.style.cssText = 'display:flex; gap:10px; justify-content:center; margin-top:15px;';
        document.getElementById('topo-map').parentNode.insertBefore(actionContainer, document.getElementById('topo-map').nextSibling);
    }
    actionContainer.innerHTML = `
        <button class="btn btn-primary" onclick="window.simulateFlyover()" style="display:flex; align-items:center; gap:5px;"><i data-lucide="play" style="width:16px;"></i> Simulasi Flyover 3D</button>
        <button class="btn" style="background:#dc3545; color:white; display:flex; align-items:center; gap:5px;" onclick="window.detectCriticalPoints()"><i data-lucide="alert-triangle" style="width:16px;"></i> Deteksi Titik Kritis</button>
    `;
    lucide.createIcons();
}

window.simulateFlyover = function() {
    if (!window.currentStravaLayer) return;
    const coords = window.currentStravaLayer.getLatLngs();
    if (coords.length === 0) return;
    
    let i = 0;
    const flyMarker = L.circleMarker(coords[0], {radius: 8, color: '#10b981', fillColor: '#10b981', fillOpacity: 1}).addTo(window.currentLeafletMap);
    window.currentLeafletMap.setZoom(16);
    
    const interval = setInterval(() => {
        if (i >= coords.length) {
            clearInterval(interval);
            setTimeout(() => window.currentLeafletMap.removeLayer(flyMarker), 3000);
            return;
        }
        flyMarker.setLatLng(coords[i]);
        window.currentLeafletMap.panTo(coords[i], {animate: true, duration: 0.1});
        i += Math.max(1, Math.floor(coords.length / 100)); // ~100 frames
    }, 100);
}

window.detectCriticalPoints = function() {
    if (!window.currentStravaLayer) return;
    const coords = window.currentStravaLayer.getLatLngs();
    if (coords.length < 10) return;
    
    // Simulate finding the steepest/most critical zone at 70% of the route
    const criticalIndex = Math.floor(coords.length * 0.7);
    const pt = coords[criticalIndex];
    
    window.currentLeafletMap.setView(pt, 15);
    L.circleMarker(pt, {radius: 12, color: '#dc3545', fillColor: '#dc3545', fillOpacity: 0.5})
        .addTo(window.currentLeafletMap)
        .bindPopup('<b style="color:#dc3545;">ZONA KRITIS / BLANK SPOT</b><br>Kepadatan kontur terekstrem terdeteksi di area ini. Hemat tenaga Anda dan waspada.')
        .openPopup();
}
// ==========================================================




// FITUR PLANNER (UPGRADED)
function renderPlanner() {
    const provKota = {"DKI Jakarta":["Jakarta Pusat","Jakarta Selatan","Jakarta Barat","Jakarta Timur"],"Jawa Barat":["Bandung","Bogor","Bekasi","Depok","Cirebon","Sukabumi","Garut"],"Jawa Tengah":["Semarang","Solo","Purwokerto","Magelang","Wonosobo"],"DIY":["Yogyakarta","Sleman"],"Jawa Timur":["Surabaya","Malang","Kediri","Batu","Lumajang","Probolinggo","Banyuwangi"],"Banten":["Tangerang","Serang","Cilegon"],"Sumatera Utara":["Medan","Berastagi"],"Sumatera Barat":["Padang","Bukittinggi"],"Lampung":["Bandar Lampung"],"Aceh":["Banda Aceh"],"Jambi":["Jambi","Sungai Penuh"],"Bali":["Denpasar","Singaraja"],"NTB":["Mataram","Senaru"],"NTT":["Kupang"],"Kalimantan Timur":["Samarinda","Balikpapan"],"Kalimantan Selatan":["Banjarmasin"],"Sulawesi Selatan":["Makassar"],"Sulawesi Utara":["Manado"],"Papua":["Jayapura","Wamena"],"Maluku":["Ambon"]};
    window._provKota = provKota;
    const provOpts = Object.keys(provKota).map(p => `<option value="${p}">${p}</option>`).join('');
    const html = `
        <div class="container py-5">
            <h1 class="section-title">Trip Planner & Kalkulator Biaya</h1>
            <div class="detail-card">
                <p>Rencanakan logistik, transportasi, dan hitung estimasi biaya pendakian secara detail dan akurat.</p>
                <hr style="border:0; border-top:1px solid var(--color-border); margin: 20px 0;">
                <div class="planner-form">
                    <div>
                        <h3 class="mb-4">Daftar Logistik & Perlengkapan Pintar</h3>
                        <div id="smart-packing-list">
                            <p style="color:var(--color-text-light); font-size:0.95rem; text-align:center; padding:40px 0;">
                                <i data-lucide="info" style="width:32px;height:32px;display:block;margin:0 auto 10px;opacity:0.5;"></i>
                                Silakan pilih gunung tujuan di sebelah kanan untuk menghasilkan daftar logistik terpersonalisasi secara otomatis berdasarkan ketinggian, status gunung, dan durasi pendakian.
                            </p>
                        </div>
                    </div>
                    <div>
                        <h3 class="mb-4"><i data-lucide="calculator" style="width:20px;height:20px;display:inline-block;vertical-align:middle;margin-right:5px;"></i> Kalkulator Biaya Rinci</h3>
                        <div style="background:var(--color-bg); padding:20px; border-radius:8px; border:1px solid var(--color-border);">
                            <div style="display:grid; gap:10px; margin-bottom:20px;">
                                <label style="font-size:0.9rem;font-weight:bold;">🏔️ Gunung Tujuan</label>
                                <select id="calc-mountain" style="padding:8px; border-radius:4px; border:1px solid #ccc; font-family:var(--font-body);" onchange="calculateCost()">
                                    <option value="">Pilih Gunung...</option>
                                    ${mountains.map(m => `<option value="${m.id}" data-prov="${m.province}" data-lat="${m.coords[0]}" data-lng="${m.coords[1]}">${m.name} (${m.province})</option>`).join('')}
                                </select>
                                <label style="font-size:0.9rem;font-weight:bold;">🏙️ Cari Kota/Kabupaten Asal</label>
                                <input type="text" id="calc-kota" list="kota-list" placeholder="Ketik nama kota... (Cth: Bandung)" style="padding:8px; border-radius:4px; border:1px solid #ccc; font-family:var(--font-body); width:100%;" oninput="calculateCost()">
                                <datalist id="kota-list">
                                    ${Object.keys(kotaCoords).sort().map(k => `<option value="${k}">`).join('')}
                                </datalist>
                                <label style="font-size:0.9rem;font-weight:bold;">🚗 Moda Transportasi</label>
                                <select id="calc-transport" style="padding:8px; border-radius:4px; border:1px solid #ccc; font-family:var(--font-body);" onchange="calculateCost()">
                                    <option value="motor">🏍️ Motor (Roda 2)</option>
                                    <option value="mobil">🚗 Mobil Pribadi (Roda 4)</option>
                                    <option value="bus">🚌 Bus / Travel</option>
                                    <option value="kereta">🚆 Kereta Api</option>
                                    <option value="pesawat">✈️ Pesawat Terbang</option>
                                </select>
                                <div style="display:flex; gap:10px;">
                                    <div style="flex:1;"><label style="font-size:0.9rem;display:block;">Jml Orang</label><input type="number" id="calc-people" value="1" min="1" style="width:100%;padding:8px;border-radius:4px;border:1px solid #ccc;" oninput="calculateCost()"></div>
                                    <div style="flex:1;"><label style="font-size:0.9rem;display:block;">Durasi (Hari)</label><input type="number" id="calc-days" value="2" min="1" style="width:100%;padding:8px;border-radius:4px;border:1px solid #ccc;" oninput="calculateCost()"></div>
                                </div>
                                <div><input type="checkbox" id="calc-guide" onchange="calculateCost()"> <label for="calc-guide" style="font-size:0.9rem;">Gunakan Jasa Porter/Guide</label></div>
                            </div>
                            <hr style="border:0; border-top:1px dashed var(--color-border); margin:15px 0;">
                            <div style="background:rgba(255, 193, 7, 0.15); color:#b45309; padding:12px 15px; border-radius:6px; font-size:0.85rem; margin-bottom:15px; border:1px solid rgba(255, 193, 7, 0.4); display:flex; gap:8px; align-items:start;">
                                <i data-lucide="alert-triangle" style="width:16px; height:16px; flex-shrink:0; margin-top:2px;"></i>
                                <div>
                                    <strong>Disclaimer:</strong> Perhitungan ini hanyalah estimasi kasar (perkiraan algoritma rata-rata). Biaya transportasi aktual, logistik, dan jasa porter di lapangan mungkin berbeda dan tidak 100% akurat sesuai kondisi nyata.
                                </div>
                            </div>
                            <div id="cost-results"><p style="text-align:center;color:var(--color-text-light);font-size:0.9rem;">Ketik/pilih gunung & kota asal untuk melihat estimasi biaya.</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    appRoot.innerHTML = html;
    setTimeout(() => { const s=document.getElementById('calc-mountain'); if(s){const o=Array.from(s.options).slice(1); o.sort((a,b)=>a.text.localeCompare(b.text)); s.innerHTML='<option value="">Pilih Gunung...</option>'; o.forEach(x=>s.add(x));} }, 0);
}

const kotaCoords = {"Jakarta Pusat":[-6.18,106.83],"Jakarta Selatan":[-6.26,106.81],"Jakarta Barat":[-6.17,106.76],"Jakarta Timur":[-6.22,106.9],"Bandung":[-6.91,107.61],"Bogor":[-6.6,106.8],"Bekasi":[-6.24,107],"Depok":[-6.4,106.82],"Cirebon":[-6.73,108.55],"Sukabumi":[-6.92,106.93],"Garut":[-7.21,107.91],"Semarang":[-6.97,110.42],"Solo":[-7.57,110.82],"Purwokerto":[-7.43,109.24],"Magelang":[-7.47,110.22],"Wonosobo":[-7.36,109.9],"Yogyakarta":[-7.8,110.36],"Sleman":[-7.72,110.36],"Surabaya":[-7.25,112.75],"Malang":[-7.98,112.63],"Kediri":[-7.82,112.02],"Batu":[-7.88,112.53],"Lumajang":[-8.13,113.22],"Probolinggo":[-7.75,113.22],"Banyuwangi":[-8.22,114.35],"Tangerang":[-6.18,106.63],"Serang":[-6.12,106.15],"Cilegon":[-6.02,106.05],"Medan":[3.59,98.67],"Berastagi":[3.19,98.51],"Padang":[-0.95,100.35],"Bukittinggi":[-0.31,100.37],"Palembang":[-2.99,104.76],"Bandar Lampung":[-5.43,105.26],"Banda Aceh":[5.55,95.32],"Jambi":[-1.59,103.61],"Sungai Penuh":[-2.06,101.39],"Denpasar":[-8.65,115.22],"Singaraja":[-8.11,115.09],"Mataram":[-8.58,116.1],"Senaru":[-8.3,116.4],"Kupang":[-10.18,123.58],"Samarinda":[-0.5,117.15],"Balikpapan":[-1.27,116.83],"Banjarmasin":[-3.32,114.59],"Makassar":[-5.14,119.42],"Manado":[1.47,124.84],"Jayapura":[-2.54,140.72],"Wamena":[-4.1,138.95],"Ambon":[-3.7,128.17]};

window.updateKotaOpts = function() {
    const prov = document.getElementById('calc-prov').value;
    const sel = document.getElementById('calc-kota');
    const cities = (window._provKota && window._provKota[prov]) || [];
    sel.innerHTML = cities.length ? cities.map(c => `<option value="${c}">${c}</option>`).join('') : '<option value="">Pilih provinsi dulu</option>';
}

function haversineKm(lat1,lon1,lat2,lon2) {
    const R=6371, dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180;
    const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
    return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

window.calculateCost = function() {
    const mSelect = document.getElementById('calc-mountain');
    const mountainId = mSelect.value;
    if(!mountainId) { document.getElementById('cost-results').innerHTML = '<p style="text-align:center; color:var(--color-text-light); font-size:0.9rem;">Pilih gunung untuk melihat estimasi.</p>'; return; }

    const mOpt = mSelect.options[mSelect.selectedIndex];
    const mountainProv = mOpt.getAttribute('data-prov');
    const mLat = parseFloat(mOpt.getAttribute('data-lat'));
    const mLng = parseFloat(mOpt.getAttribute('data-lng'));
    const kota = document.getElementById('calc-kota').value;
    const transport = document.getElementById('calc-transport').value;
    const people = parseInt(document.getElementById('calc-people').value) || 1;
    const days = parseInt(document.getElementById('calc-days').value) || 1;
    const useGuide = document.getElementById('calc-guide').checked;
    const fmt = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

    // Hitung jarak dari kota ke gunung
    let distKm = 0;
    if (kota) {
        // Cari di kotaCoords secara case-insensitive
        const matchedCityKey = Object.keys(kotaCoords).find(k => k.toLowerCase() === kota.toLowerCase());
        
        if (matchedCityKey) {
            distKm = Math.round(haversineKm(kotaCoords[matchedCityKey][0], kotaCoords[matchedCityKey][1], mLat, mLng) * 1.3);
        } else {
            // Kota tidak ditemukan di database
            document.getElementById('cost-results').innerHTML = `<p style="text-align:center; color:#dc3545; font-size:0.9rem;">Kota "${kota}" belum ada di database kami. Silakan pilih kota terdekat dari dropdown / saran pencarian.</p>`;
            return;
        }
    } else {
        document.getElementById('cost-results').innerHTML = '<p style="text-align:center; color:var(--color-text-light); font-size:0.9rem;">Pilih gunung & kota asal untuk melihat estimasi.</p>';
        return;
    }

    const hargaBBM = 10000; // Pertalite 2026
    let tCost = 0, tLabel = '', tDetail = '';

    if (transport === 'motor') {
        const kpl = 45; const ltr = Math.ceil((distKm*2)/kpl);
        tCost = ltr * hargaBBM; tLabel = '🏍️ Motor (BBM PP)';
        tDetail = `${distKm}km × 2(PP) ÷ ${kpl}km/L = ${ltr}L × ${fmt.format(hargaBBM)}`;
    } else if (transport === 'mobil') {
        const kpl = 12; const ltr = Math.ceil((distKm*2)/kpl);
        tCost = ltr * hargaBBM; tLabel = '🚗 Mobil (BBM PP)';
        tDetail = `${distKm}km × 2(PP) ÷ ${kpl}km/L = ${ltr}L × ${fmt.format(hargaBBM)}`;
    } else if (transport === 'bus') {
        const rate = distKm > 500 ? 150 : 200;
        tCost = distKm * rate * 2; tLabel = '🚌 Bus/Travel (PP)';
        tDetail = `${distKm}km × Rp${rate}/km × 2(PP)`;
    } else if (transport === 'kereta') {
        const base = distKm > 400 ? 350000 : (distKm > 200 ? 200000 : 100000);
        tCost = base * 2; tLabel = '🚆 Kereta Api (PP)';
        tDetail = `Estimasi tiket ekonomi/bisnis jarak ${distKm}km`;
    } else if (transport === 'pesawat') {
        const base = distKm > 1500 ? 2500000 : (distKm > 800 ? 1500000 : (distKm > 400 ? 900000 : 600000));
        tCost = base * 2; tLabel = '✈️ Pesawat (PP)';
        tDetail = `Estimasi tiket ekonomi jarak ${distKm}km`;
    }

    let simaksi = 35000 * days;
    if(mountainProv.includes('Papua')) simaksi = 150000 * days;
    if(mountainProv.includes('Bali') || mountainProv.includes('NTB') || mountainProv.includes('NTT')) simaksi = 50000 * days;
    const logistik = 75000 * days;
    const guide = useGuide ? (400000 * days) : 0;
    const guideShare = Math.round(guide / people);
    const tShare = (transport === 'mobil') ? Math.round(tCost / people) : tCost;
    const totalPerOrg = simaksi + logistik + tShare + guideShare;
    const totalAll = totalPerOrg * people;

    document.getElementById('cost-results').innerHTML = `<div style="background:var(--color-bg); padding:15px; border-radius:8px; border:1px solid var(--color-border);"><div style="margin-bottom:10px;"><strong style="color:var(--color-primary);"><i data-lucide="check-circle" style="width:16px;"></i> ${tLabel}:</strong><br><span style="font-size:0.9rem;color:var(--color-text-light);">${tDetail}</span><div style="font-weight:bold;">${fmt.format(tCost)}</div></div><div style="margin-bottom:10px;"><strong style="color:var(--color-primary);"><i data-lucide="check-circle" style="width:16px;"></i> Simaksi & Asuransi (${days} Hari):</strong><br><div style="font-weight:bold;">${fmt.format(simaksi)} per orang</div></div><div style="margin-bottom:10px;"><strong style="color:var(--color-primary);"><i data-lucide="check-circle" style="width:16px;"></i> Logistik & Makan (${days} Hari):</strong><br><div style="font-weight:bold;">${fmt.format(logistik)} per orang</div></div>${useGuide?`<div style="margin-bottom:10px;"><strong style="color:var(--color-primary);"><i data-lucide="check-circle" style="width:16px;"></i> Guide/Porter (${days} Hari):</strong><br><span style="font-size:0.9rem;color:var(--color-text-light);">Total ${fmt.format(guide)}, dibagi ${people} orang</span><div style="font-weight:bold;">${fmt.format(guideShare)} per orang</div></div>`:''}<hr style="border:0; border-top:1px solid var(--color-border); margin:15px 0;"><div style="display:flex;justify-content:space-between;align-items:center;"><div><div style="font-size:0.9rem;">Total Est. per Orang</div><div style="font-size:1.8rem; font-weight:bold; color:var(--color-accent);">${fmt.format(totalPerOrg)}</div></div><div style="text-align:right;"><div style="font-size:0.8rem;color:var(--color-text-light);">Total Rombongan (${people} Org)</div><div style="font-weight:bold; font-size:1.1rem;">${fmt.format(totalAll)}</div></div></div></div>`;
    lucide.createIcons();
    updateSmartChecklist(mountainId, days);
}

// FITUR PERBANDINGAN GUNUNG (COMPARE)
function renderCompare() {
    const opts = mountains.map(m => `<option value="${m.id}">${m.name} (${m.province})</option>`).join('');
    
    const html = `
        <div class="container py-5">
            <h1 class="section-title">Perbandingan Gunung</h1>
            <div class="detail-card">
                <p class="text-center" style="margin-bottom:20px;">Bandingkan dua gunung secara berdampingan untuk melihat tingkat kesulitan, estimasi trek, dan kondisi alam yang lebih cocok dengan kemampuanmu.</p>
                <div style="display:flex; gap:15px; flex-wrap:wrap; margin-bottom:20px; justify-content:center;">
                    <select id="compare-1" style="padding:10px; border-radius:8px; border:1px solid var(--color-border); font-family:var(--font-body); flex:1; min-width:200px;">
                        <option value="">-- Pilih Gunung 1 --</option>
                        ${opts}
                    </select>
                    <span style="display:flex; align-items:center; font-weight:900; color:var(--color-primary);">VS</span>
                    <select id="compare-2" style="padding:10px; border-radius:8px; border:1px solid var(--color-border); font-family:var(--font-body); flex:1; min-width:200px;">
                        <option value="">-- Pilih Gunung 2 --</option>
                        ${opts}
                    </select>
                </div>
                <div style="text-align:center;">
                    <button class="btn btn-primary" onclick="doCompare()"><i data-lucide="scale"></i> Bandingkan Sekarang</button>
                </div>
            </div>
            <div id="compare-result" style="margin-top:30px;"></div>
        </div>
    `;
    appRoot.innerHTML = html;
    lucide.createIcons();
}

window.doCompare = function() {
    const id1 = document.getElementById('compare-1').value;
    const id2 = document.getElementById('compare-2').value;
    const resDiv = document.getElementById('compare-result');
    
    if(!id1 || !id2) {
        resDiv.innerHTML = '<p class="text-center" style="color:var(--color-danger);">Silakan pilih dua gunung yang berbeda untuk dibandingkan.</p>';
        return;
    }
    if(id1 === id2) {
        resDiv.innerHTML = '<p class="text-center" style="color:var(--color-danger);">Pilih dua gunung yang berbeda!</p>';
        return;
    }

    const m1 = mountains.find(m => m.id === id1);
    const m2 = mountains.find(m => m.id === id2);
    
    const est1 = getTrekEstimates(m1.elevation, m1.difficulty, m1.id);
    const est2 = getTrekEstimates(m2.elevation, m2.difficulty, m2.id);

    let score1 = 0; let score2 = 0;
    let reason = '';
    
    if(m1.difficulty > m2.difficulty) { score2++; } else if(m2.difficulty > m1.difficulty) { score1++; }
    if(m1.elevation > m2.elevation) { score2++; } else if(m2.elevation > m1.elevation) { score1++; }
    if(m1.status === 'Tidak Aktif' && m2.status === 'Aktif') { score1++; } else if(m2.status === 'Tidak Aktif' && m1.status === 'Aktif') { score2++; }
    
    let winner = null;
    if(score1 > score2) {
        winner = m1.name;
        reason = `${m1.name} dinilai lebih ramah untuk didaki karena memiliki profil elevasi, tingkat bahaya, atau kesulitan teknis yang lebih rendah dibanding ${m2.name}.`;
    } else if(score2 > score1) {
        winner = m2.name;
        reason = `${m2.name} dinilai lebih ramah untuk didaki karena memiliki profil elevasi, tingkat bahaya, atau kesulitan teknis yang lebih rendah dibanding ${m1.name}.`;
    } else {
        winner = "Seimbang (Karakteristik Mirip)";
        reason = `Kedua gunung memiliki tingkat kesulitan dan risiko yang hampir setara.`;
    }

    resDiv.innerHTML = `
        <div class="detail-card">
            <h3 class="text-center" style="color:var(--color-accent); font-size:1.4rem; margin-bottom:10px;">🏆 Rekomendasi Keselamatan: ${winner}</h3>
            <p class="text-center" style="margin-bottom:25px; color:var(--color-text-light); font-size:0.95rem;">${reason}</p>
            <div style="overflow-x:auto;">
                <table style="width:100%; min-width:600px; text-align:left; border-collapse:collapse;">
                    <thead><tr style="background:var(--color-primary); color:white;"><th style="padding:15px;">Parameter</th><th style="padding:15px;">${m1.name}</th><th style="padding:15px;">${m2.name}</th></tr></thead>
                    <tbody>
                        <tr><td style="padding:15px; border-bottom:1px solid var(--color-border); font-weight:bold;">Tingkat Kesulitan</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${getDifficultyBadge(m1.difficulty)}</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${getDifficultyBadge(m2.difficulty)}</td></tr>
                        <tr style="background:rgba(21,50,25,0.02);"><td style="padding:15px; border-bottom:1px solid var(--color-border); font-weight:bold;">Ketinggian</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${m1.elevation} mdpl</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${m2.elevation} mdpl</td></tr>
                        <tr><td style="padding:15px; border-bottom:1px solid var(--color-border); font-weight:bold;">Status Vulkanik</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${m1.status === 'Aktif' ? '<span style="color:#dc3545;font-weight:bold;">Aktif</span>' : '<span style="color:#198754;font-weight:bold;">Tidak Aktif</span>'}</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${m2.status === 'Aktif' ? '<span style="color:#dc3545;font-weight:bold;">Aktif</span>' : '<span style="color:#198754;font-weight:bold;">Tidak Aktif</span>'}</td></tr>
                        <tr style="background:rgba(21,50,25,0.02);"><td style="padding:15px; border-bottom:1px solid var(--color-border); font-weight:bold;">Estimasi Jarak (PP)</td><td style="padding:15px; border-bottom:1px solid var(--color-border); color:var(--color-accent); font-weight:bold;">${est1.distancePP}</td><td style="padding:15px; border-bottom:1px solid var(--color-border); color:var(--color-accent); font-weight:bold;">${est2.distancePP}</td></tr>
                        <tr><td style="padding:15px; border-bottom:1px solid var(--color-border); font-weight:bold;">Waktu Tempuh</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${est1.duration}</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${est2.duration}</td></tr>
                        <tr style="background:rgba(21,50,25,0.02);"><td style="padding:15px; border-bottom:1px solid var(--color-border); font-weight:bold;">Peta GPX</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${m1.hasGpx ? '✅ Tersedia' : '❌ Tidak Ada'}</td><td style="padding:15px; border-bottom:1px solid var(--color-border);">${m2.hasGpx ? '✅ Tersedia' : '❌ Tidak Ada'}</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    `;
    lucide.createIcons();
}

window.syncSmartLogbook = async function() {
    const btn = document.getElementById('btn-sync-logbook');
    if (btn) btn.innerHTML = '<i data-lucide="loader" class="spin" style="width:18px;"></i> Memindai Satelit...';
    lucide.createIcons();
    
    const token = await getStravaAccessToken();
    if (!token) {
        alert("Gagal terhubung ke satelit verifikasi. Coba lagi nanti.");
        if (btn) btn.innerHTML = '<i data-lucide="satellite" style="width:18px;"></i> Sinkronkan dengan Satelit Pintar';
        lucide.createIcons();
        return;
    }
    
    try {
        const res = await fetch('https://www.strava.com/api/v3/athlete/activities?per_page=30', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const activities = await res.json();
        
        let addedCount = 0;
        activities.forEach(act => {
            // Check if activity matches any mountain name
            const match = mountains.find(m => act.name.toLowerCase().includes(m.name.toLowerCase()));
            if (match) {
                // Prevent duplicate
                const exists = savedLogbook.find(l => l.stravaId === act.id);
                if (!exists) {
                    savedLogbook.push({
                        stravaId: act.id,
                        date: new Date(act.start_date).toLocaleDateString('id-ID', {day: 'numeric', month: 'long', year: 'numeric'}),
                        mountain: match.name,
                        mountainId: match.id,
                        status: 'Terverifikasi Satelit',
                        rating: 5,
                        notes: `Tercatat otomatis dari Satelit Pintar (Jarak: ${(act.distance/1000).toFixed(2)} km, Waktu Aktif: ${Math.round(act.moving_time/60)} menit).`
                    });
                    addedCount++;
                }
            }
        });
        
        if (addedCount > 0) {
            localStorage.setItem('puncakNusantara_logbook', JSON.stringify(savedLogbook));
            alert(`Berhasil menarik ${addedCount} data pendakian baru dari riwayat satelitmu!`);
            renderLogbook(); // re-render
        } else {
            alert("Sistem tidak mendeteksi adanya riwayat pendakian baru di data satelitmu yang cocok dengan daftar gunung kami.");
        }
    } catch(e) {
        console.error(e);
        alert("Terjadi kesalahan sinkronisasi data satelit.");
    }
    
    if (btn) {
        btn.innerHTML = '<i data-lucide="satellite" style="width:18px;"></i> Sinkronkan dengan Satelit Pintar';
        lucide.createIcons();
    }
}

function renderLogbook() {
    // If no logs, show empty state instead of hardcoded sample
    const displayLogs = savedLogbook;

    let historyHtml = '';
    if (displayLogs.length === 0) {
        historyHtml = '<div style="text-align:center; color:var(--color-text-light); padding:30px;">Belum ada catatan perjalanan. Hubungkan ke satelit atau tambah manual.</div>';
    } else {
        // Sort newest first based on rough assumption or just reverse array
        const sortedLogs = [...displayLogs].reverse();
        historyHtml = sortedLogs.map(log => 
            `<div class="logbook-entry" style="background:var(--color-card-bg); border:1px solid ${log.status === 'Terverifikasi Satelit' ? 'var(--color-primary)' : 'var(--color-border)'}; padding:15px; border-radius:8px; margin-bottom:15px; position:relative; overflow:hidden;">
                ${log.status === 'Terverifikasi Satelit' ? '<div style="position:absolute; top:0; right:0; background:var(--color-primary); color:white; font-size:0.7rem; font-weight:bold; padding:4px 10px; border-bottom-left-radius:8px;"><i data-lucide="check-circle" style="width:12px; display:inline-block;"></i> Verified</div>' : ''}
                <div style="font-size:0.8rem; color:var(--color-text-light); margin-bottom:5px;">${log.date}</div>
                <h4 style="margin:0 0 5px 0; color:var(--color-accent); font-size:1.1rem;">${log.mountain}</h4>
                <div style="font-size:0.85rem; color:var(--color-text); font-style:italic;">"${log.notes}"</div>
            </div>`
        ).join('');
    }

    const html = `
        <div class="container py-5">
            <h1 class="section-title">Logbook Pribadi</h1>
            <p style="text-align:center; color:var(--color-text-light); margin-bottom:30px;">Catat dan lacak seluruh pencapaian pendakianmu.</p>
            
            <div style="text-align:center; margin-bottom:30px;">
                <button id="btn-sync-logbook" class="btn btn-primary" style="display:inline-flex; align-items:center; gap:8px; padding:12px 25px; font-weight:bold; font-size:1rem; border-radius:30px; box-shadow:0 4px 15px rgba(230,95,18,0.3);" onclick="window.syncSmartLogbook()">
                    <i data-lucide="satellite" style="width:18px;"></i> Sinkronkan dengan Satelit Pintar
                </button>
                <div style="font-size:0.8rem; color:var(--color-text-light); margin-top:8px;">Otomatis merekap riwayat pendakian dari perangkat GPS/Jam Tanganmu.</div>
            </div>

            <div class="grid" style="grid-template-columns: 1fr 2fr;">
                <div class="detail-card">
                    <h3 style="text-align:center;"><i data-lucide="award"></i> Total Pencapaian</h3>
                    <div style="text-align:center; padding: 20px 0; font-size:4rem; font-weight:900; color:var(--color-accent); line-height:1;">${displayLogs.length}</div>
                    <div style="text-align:center; font-size:0.9rem; color:var(--color-text-light);">Gunung Ditaklukkan</div>
                </div>
                <div class="detail-card">
                    <h3 style="margin-bottom:20px;"><i data-lucide="book-open"></i> Riwayat Perjalanan</h3>
                    <div>
                        ${historyHtml}
                    </div>
                </div>
            </div>
        </div>
    `;
    appRoot.innerHTML = html;
    lucide.createIcons();
}

function initElevationChart(id) {
    if (typeof gpxData === 'undefined' || !gpxData[id]) return;
    
    try {
        const parser = new DOMParser();
        const xmlDoc = parser.parseFromString(gpxData[id], "text/xml");
        const eleElements = xmlDoc.getElementsByTagName("ele");
        const elevations = Array.from(eleElements).map(el => parseFloat(el.textContent));
        
        const labels = elevations.map((_, index) => "Pos " + (index + 1));
        const ctx = document.getElementById('elevationChart').getContext('2d');
        
        const theme = localStorage.getItem('theme') || 'light';
        const gridColor = theme === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.05)';
        const textColor = theme === 'dark' ? '#aaaaaa' : '#555555';
        const accentColor = theme === 'dark' ? '#ff7d3b' : '#e65f12';

        if (window.currentElevationChart) {
            window.currentElevationChart.destroy();
        }

        window.currentElevationChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Ketinggian (mdpl)',
                    data: elevations,
                    borderColor: accentColor,
                    backgroundColor: 'rgba(230, 95, 18, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        grid: { color: gridColor },
                        ticks: { color: textColor }
                    },
                    y: {
                        grid: { color: gridColor },
                        ticks: { color: textColor }
                    }
                }
            }
        });
    } catch(e) {
        console.error("Gagal menggambar chart ketinggian", e);
    }
}

function updateSmartChecklist(mountainId, days) {
    const m = mountains.find(x => x.id === mountainId);
    if (!m) return;
    
    const docs = [
        "KTP Asli & Fotokopi",
        "Surat Keterangan Sehat Asli",
        "Bukti Registrasi / Simaksi Online"
    ];
    
    const gears = [
        "Tenda dome double layer",
        "Sleeping bag comfort minimal 10°C",
        "Matras / Matras aluminium foil",
        "Kompor gas portable + tabung gas cadangan",
        "Nesting & alat makan",
        "Headlamp / Senter + baterai cadangan",
        "Pakaian trekking taktis (base & mid layer)",
        "Sepatu trekking grip kuat + kaos kaki tebal",
        "Trash bag / kantong sampah (Wajib Zero Waste!)",
        "Peralatan P3K pribadi & obat maag/pusing"
    ];
    
    if (m.elevation >= 3000) {
        gears.push("Jaket Bulu Angsa / Down Jacket (Suhu ekstrem)");
        gears.push("Sleeping bag comfort limit 0°C - 5°C");
        gears.push("Sarung tangan windproof & kupluk wol (Balaclava)");
        gears.push("Emergency thermal blanket");
    }
    
    if (m.status === 'Aktif') {
        gears.push("Masker respirator / masker karbon aktif (antisipasi bau gas belerang)");
        gears.push("Kacamata goggles / pelindung mata");
        gears.push("Obat tetes mata steril");
    }
    
    if (!m.hasGpx) {
        gears.push("Aplikasi Navigasi Offline (misal: OsmAnd/Avenza) + peta offline");
        gears.push("Powerbank kapasitas besar (minimal 15.000 mAh)");
    }
    
    let logistik = [
        "Beras & mi instan/makanan cepat saji",
        "Cokelat batang / gula merah (penambah energi cepat)",
        "Air minum bersih (minimal 3 Liter per orang per hari)"
    ];
    
    if (days >= 3) {
        logistik.push("Daging kering / abon / kornet (sumber protein tahan lama)");
        logistik.push("Multivitamin & suplemen oralit/dekstrosa");
        logistik.push("Tabung gas tambahan (minimal 3 kaleng untuk 3 hari+)");
    }
    
    const html = `
        <div class="checklist-category" style="margin-bottom: 20px;">
            <h4><i data-lucide="file-text" style="width:16px;height:16px;display:inline-block;vertical-align:middle;margin-right:5px;"></i> Administrasi & Dokumen</h4>
            ${docs.map((d, i) => `
                <div class="checkbox-item">
                    <input type="checkbox" id="d_${i}">
                    <label for="d_${i}">${d}</label>
                </div>
            `).join('')}
        </div>
        
        <div class="checklist-category" style="margin-bottom: 20px;">
            <h4><i data-lucide="backpack" style="width:16px;height:16px;display:inline-block;vertical-align:middle;margin-right:5px;"></i> Perlengkapan Utama (Medan & Ketinggian)</h4>
            ${gears.map((g, i) => `
                <div class="checkbox-item">
                    <input type="checkbox" id="g_${i}">
                    <label for="g_${i}">${g}</label>
                </div>
            `).join('')}
        </div>
        
        <div class="checklist-category">
            <h4><i data-lucide="cookie" style="width:16px;height:16px;display:inline-block;vertical-align:middle;margin-right:5px;"></i> Logistik Masak (Estimasi ${days} Hari)</h4>
            ${logistik.map((l, i) => `
                <div class="checkbox-item">
                    <input type="checkbox" id="l_${i}">
                    <label for="l_${i}">${l}</label>
                </div>
            `).join('')}
        </div>
        
        <div style="margin-top: 25px;">
            <button class="btn btn-outline" onclick="window.print()" style="width:100%;"><i data-lucide="printer"></i> Cetak Rencana Perjalanan (PDF)</button>
        </div>
    `;
    
    document.getElementById('smart-packing-list').innerHTML = html;
    lucide.createIcons();
}

// =====================================================
// FITUR PREMIUM: ACHIEVEMENT / BADGE SYSTEM (Gamifikasi)
// =====================================================
function getAchievementsHtml() {
    const logbook = JSON.parse(localStorage.getItem('puncakNusantara_logbook')) || [];
    const visited = logbook.length;
    const visitedIds = logbook.map(l => l.mountainId);
    
    const achievements = [
        {
            id: 'first_summit',
            icon: '🏔️',
            title: 'Summit Pertama',
            desc: 'Catat pendakian pertamamu di Logbook',
            unlocked: visited >= 1,
            progress: Math.min(visited, 1),
            max: 1
        },
        {
            id: 'explorer_5',
            icon: '🧭',
            title: 'Penjelajah Sejati',
            desc: 'Daki 5 gunung berbeda',
            unlocked: visited >= 5,
            progress: Math.min(visited, 5),
            max: 5
        },
        {
            id: 'collector_10',
            icon: '👑',
            title: 'Raja Nusantara',
            desc: 'Daki 10 gunung berbeda',
            unlocked: visited >= 10,
            progress: Math.min(visited, 10),
            max: 10
        },
        {
            id: 'above_3000',
            icon: '🦅',
            title: 'Sang Elang',
            desc: 'Daki gunung di atas 3000 mdpl',
            unlocked: logbook.some(l => {
                const m = mountains.find(x => x.id === l.mountainId);
                return m && m.elevation >= 3000;
            }),
            progress: logbook.filter(l => {
                const m = mountains.find(x => x.id === l.mountainId);
                return m && m.elevation >= 3000;
            }).length > 0 ? 1 : 0,
            max: 1
        },
        {
            id: 'java_complete',
            icon: '🌋',
            title: 'Penakluk Jawa',
            desc: 'Daki gunung dari 3 provinsi Jawa',
            unlocked: (() => {
                const javaProv = ['Jawa Barat', 'Jawa Tengah', 'Jawa Timur', 'Banten', 'DIY'];
                const visitedProv = new Set();
                logbook.forEach(l => {
                    const m = mountains.find(x => x.id === l.mountainId);
                    if (m && javaProv.includes(m.province)) visitedProv.add(m.province);
                });
                return visitedProv.size >= 3;
            })(),
            progress: (() => {
                const javaProv = ['Jawa Barat', 'Jawa Tengah', 'Jawa Timur', 'Banten', 'DIY'];
                const visitedProv = new Set();
                logbook.forEach(l => {
                    const m = mountains.find(x => x.id === l.mountainId);
                    if (m && javaProv.includes(m.province)) visitedProv.add(m.province);
                });
                return Math.min(visitedProv.size, 3);
            })(),
            max: 3
        },
        {
            id: 'reviewer',
            icon: '✍️',
            title: 'Kontributor',
            desc: 'Tulis review di 3 gunung',
            unlocked: (() => {
                let count = 0;
                mountains.forEach(m => {
                    const c = JSON.parse(localStorage.getItem('comments_' + m.id));
                    if (c && c.length > 0) count++;
                });
                return count >= 3;
            })(),
            progress: (() => {
                let count = 0;
                mountains.forEach(m => {
                    const c = JSON.parse(localStorage.getItem('comments_' + m.id));
                    if (c && c.length > 0) count++;
                });
                return Math.min(count, 3);
            })(),
            max: 3
        }
    ];
    
    return achievements.map(a => {
        const pct = Math.round((a.progress / a.max) * 100);
        return `
            <div style="background:var(--color-card-bg); border:1px solid ${a.unlocked ? 'var(--color-accent)' : 'var(--color-border)'}; border-radius:12px; padding:20px; text-align:center; position:relative; overflow:hidden; transition:transform 0.3s; ${a.unlocked ? 'box-shadow:0 0 15px rgba(230,95,18,0.15);' : 'opacity:0.6;'}" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='translateY(0)'">
                ${a.unlocked ? '<div style="position:absolute; top:8px; right:8px; background:var(--color-accent); color:white; border-radius:50%; width:22px; height:22px; font-size:12px; display:flex; align-items:center; justify-content:center;">✓</div>' : ''}
                <div style="font-size:2.2rem; margin-bottom:8px; ${a.unlocked ? '' : 'filter:grayscale(1);'}">${a.icon}</div>
                <div style="font-weight:bold; font-size:0.95rem; margin-bottom:4px; color:${a.unlocked ? 'var(--color-accent)' : 'var(--color-text)'};">${a.title}</div>
                <div style="font-size:0.8rem; color:var(--color-text-light); margin-bottom:10px;">${a.desc}</div>
                <div style="background:var(--color-bg); border-radius:20px; height:8px; overflow:hidden;">
                    <div style="height:100%; width:${pct}%; background:${a.unlocked ? 'var(--color-accent)' : 'var(--color-text-light)'}; border-radius:20px; transition:width 0.5s;"></div>
                </div>
                <div style="font-size:0.75rem; color:var(--color-text-light); margin-top:5px;">${a.progress}/${a.max}</div>
            </div>
        `;
    }).join('');
}

// Note: Sunrise/Sunset feature has been removed.

// =====================================================
// FITUR PREMIUM: SHARE MOUNTAIN
// =====================================================
window.shareMountain = function(name, elevation, province) {
    const shareText = `🏔️ Gunung ${name} (${elevation} mdpl) - ${province}\n\nCek info lengkap jalur, cuaca real-time, dan tips pendakian di PuncakNusantara!\n\n${window.location.href}`;
    
    if (navigator.share) {
        navigator.share({
            title: `Gunung ${name} - PuncakNusantara`,
            text: shareText,
            url: window.location.href
        }).catch(() => {});
    } else {
        // Fallback: copy to clipboard
        navigator.clipboard.writeText(shareText).then(() => {
            const toast = document.createElement('div');
            toast.style.cssText = 'position:fixed; bottom:30px; left:50%; transform:translateX(-50%); background:var(--color-primary); color:white; padding:12px 25px; border-radius:var(--radius-full); font-size:0.95rem; z-index:99999; box-shadow:0 10px 25px rgba(0,0,0,0.3); animation:fadeInUp 0.3s ease;';
            toast.innerHTML = '<i data-lucide="check-circle" style="width:16px; height:16px; display:inline-block; vertical-align:middle; margin-right:8px;"></i> Link berhasil disalin ke clipboard!';
            document.body.appendChild(toast);
            lucide.createIcons();
            setTimeout(() => toast.remove(), 3000);
        }).catch(() => {
            prompt('Salin link ini:', window.location.href);
        });
    }
}

// =====================================================
// FITUR PREMIUM: GUNUNG REKOMENDASI HARI INI
// =====================================================
function getMountainOfTheDayHtml() {
    // Seed berdasarkan tanggal agar konsisten sepanjang hari
    const today = new Date();
    const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
    const index = seed % mountains.length;
    const m = mountains[index];
    
    const oxygenLevel = (20.9 * Math.exp(-m.elevation / 7400)).toFixed(1);
    const diffMap = {1: 'Pemula', 2: 'Menengah', 3: 'Sulit', 4: 'Ekstrem'};
    
    return `
        <div class="motd-card">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:20px;">
                <div style="flex:1; min-width:250px;">
                    <div style="font-size:0.85rem; text-transform:uppercase; letter-spacing:2px; opacity:0.7; margin-bottom:8px;">
                        <i data-lucide="star" style="width:14px; height:14px; display:inline-block; vertical-align:middle;"></i> Pick of the Day
                    </div>
                    <h2 style="font-size:2rem; font-family:var(--font-display); margin:0 0 8px 0;">${m.name}</h2>
                    <p style="opacity:0.85; font-size:1rem; margin-bottom:20px;">${m.province} &bull; ${m.elevation} mdpl &bull; Level ${diffMap[m.difficulty] || '?'}</p>
                    <p style="opacity:0.7; font-size:0.95rem; line-height:1.6; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${m.description}</p>
                    <div style="margin-top:20px; display:flex; gap:12px; flex-wrap:wrap;">
                        <a href="#mountain/${m.id}" class="btn" style="background:var(--color-accent); color:white; padding:10px 22px; border-radius:var(--radius-full); font-weight:bold; text-decoration:none; display:inline-flex; align-items:center; gap:8px;">
                            <i data-lucide="arrow-right" style="width:16px; height:16px;"></i> Lihat Detail
                        </a>
                        <div style="display:flex; align-items:center; gap:8px; background:rgba(255,255,255,0.15); padding:8px 16px; border-radius:var(--radius-full); font-size:0.85rem;">
                            <i data-lucide="wind" style="width:14px; height:14px;"></i> O₂: ${oxygenLevel}%
                        </div>
                    </div>
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; min-width:200px;">
                    <div style="background:rgba(255,255,255,0.1); padding:12px; border-radius:10px; text-align:center;">
                        <div style="font-size:1.5rem; font-weight:bold;">${m.routes.length}</div>
                        <div style="font-size:0.75rem; opacity:0.7;">Jalur Resmi</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.1); padding:12px; border-radius:10px; text-align:center;">
                        <div style="font-size:1.5rem; font-weight:bold;">${m.difficulty}/4</div>
                        <div style="font-size:0.75rem; opacity:0.7;">Kesulitan</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.1); padding:12px; border-radius:10px; text-align:center;">
                        <div style="font-size:1.5rem; font-weight:bold;">${m.hasGpx ? '✅' : '❌'}</div>
                        <div style="font-size:0.75rem; opacity:0.7;">GPX Ready</div>
                    </div>
                    <div style="background:rgba(255,255,255,0.1); padding:12px; border-radius:10px; text-align:center;">
                        <div style="font-size:1.5rem; font-weight:bold;">${m.elevation >= 3000 ? '⚠️' : '✅'}</div>
                        <div style="font-size:0.75rem; opacity:0.7;">Risiko AMS</div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// =====================================================
// FITUR 1: LEAFLET TOPO MAP
// =====================================================
window.initTopoMap = function(m) {
    const mapEl = document.getElementById('topo-map');
    if (!mapEl) return;
    
    // Initialize map focused on mountain coords
    window.currentLeafletMap = L.map('topo-map', { scrollWheelZoom: false }).setView([m.coords[0], m.coords[1]], 13);
    const map = window.currentLeafletMap;
    
    // Add OpenTopoMap layer
    L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        maxZoom: 17,
        attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
    }).addTo(map);

    // Add peak marker
    L.marker([m.coords[0], m.coords[1]]).addTo(map)
        .bindPopup(`<b>${m.name}</b><br>Ketinggian: ${m.elevation} mdpl`)
        .openPopup();

    // If GPX data exists, try to overlay it using leaflet-gpx if loaded
    if (m.hasGpx && typeof gpxData !== 'undefined' && gpxData[m.id] && typeof L.GPX !== 'undefined') {
        const gpxUrl = 'data:application/gpx+xml;base64,' + btoa(unescape(encodeURIComponent(gpxData[m.id])));
        new L.GPX(gpxUrl, {
            async: true,
            marker_options: {
                startIconUrl: '', endIconUrl: '', shadowUrl: '' // Hide default gpx markers
            },
            polyline_options: {
                color: '#dc2626', opacity: 0.8, weight: 4, lineCap: 'round'
            }
        }).on('loaded', function(e) {
            map.fitBounds(e.target.getBounds());
        }).addTo(map);
    }
}

// =====================================================
// FITUR 2: AUDIO BRIEFING (TEXT TO SPEECH)
// =====================================================
window.playAudioBriefing = function(name, elevation, diffLevel) {
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel(); // Stop current playing
        
        const difficultyMap = {1: 'sangat ramah untuk pemula', 2: 'cukup menantang untuk tingkat menengah', 3: 'sulit dan butuh fisik kuat', 4: 'sangat ekstrem, hanya untuk profesional'};
        const diffText = difficultyMap[diffLevel] || 'menantang';
        
        const text = `Selamat datang di data center Gunung ${name}. Gunung ini memiliki ketinggian ${elevation} meter di atas permukaan laut. Jalur pendakian di gunung ini masuk dalam kategori ${diffText}. Persiapkan fisik, mental, dan logistik Anda dengan matang. Selamat mendaki dan jaga kelestarian alam.`;
        
        const msg = new SpeechSynthesisUtterance(text);
        msg.lang = 'id-ID';
        msg.rate = 0.9;
        msg.pitch = 1.0;
        
        // Coba cari voice bahasa indonesia Google jika ada
        const voices = window.speechSynthesis.getVoices();
        const indoVoice = voices.find(v => v.lang.includes('id') || v.lang.includes('ID'));
        if (indoVoice) msg.voice = indoVoice;
        
        window.speechSynthesis.speak(msg);
        
        // Tampilkan toast
        const toast = document.createElement('div');
        toast.style.cssText = 'position:fixed; bottom:30px; left:50%; transform:translateX(-50%); background:var(--color-primary); color:white; padding:12px 25px; border-radius:var(--radius-full); font-size:0.95rem; z-index:99999; box-shadow:0 10px 25px rgba(0,0,0,0.3); animation:fadeInUp 0.3s ease; display:flex; align-items:center; gap:10px;';
        toast.innerHTML = '<i data-lucide="volume-2" style="width:16px;"></i> Memainkan Audio Briefing...';
        document.body.appendChild(toast);
        lucide.createIcons();
        setTimeout(() => toast.remove(), 4000);
    } else {
        alert("Maaf, browser Anda tidak mendukung fitur Voice Audio.");
    }
}



// =====================================================
// FITUR 4: KALKULATOR KALORI & AIR PINTAR
// =====================================================
window.calculateCalorieWater = function(elevation, difficulty) {
    const weight = parseFloat(document.getElementById('user-weight').value);
    if (!weight || weight < 30) {
        alert("Masukkan berat badan yang valid (minimal 30kg).");
        return;
    }
    
    // Rumus Estimasi kasar: (Berat Badan * 8 METs) * (Durasi Kasar berdasarkan tinggi)
    // Asumsi: Gunung >3000m butuh ~10 jam (pp), <3000m ~7 jam, <2000m ~4 jam
    let hours = elevation > 3000 ? 12 : (elevation > 2000 ? 8 : 5);
    hours = hours * (1 + (difficulty * 0.1)); // Semakin sulit, tambah waktu
    
    // Kalori: Berat(kg) * MET (Metabolic Equivalent ~7 untuk mendaki) * jam
    const kaloriTerbakar = Math.round(weight * 7.5 * hours);
    
    // Kebutuhan Air: Umumnya 0.5 Liter per jam aktivitas mendaki per orang
    const kebutuhanAirLiters = (0.5 * hours).toFixed(1);
    
    const resDiv = document.getElementById('calorie-result');
    resDiv.style.display = 'block';
    resDiv.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:10px; border-bottom:1px solid var(--color-border); padding-bottom:8px;">
            <span style="font-weight:bold; color:var(--color-primary);"><i data-lucide="flame" style="width:16px;"></i> Estimasi Kalori Terbakar</span>
            <span style="font-weight:bold; font-size:1.1rem; color:var(--color-accent);">${new Intl.NumberFormat('id-ID').format(kaloriTerbakar)} kkal</span>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:10px; border-bottom:1px solid var(--color-border); padding-bottom:8px;">
            <span style="font-weight:bold; color:var(--color-primary);"><i data-lucide="droplets" style="width:16px;"></i> Minimal Air Bawaan (Personal)</span>
            <span style="font-weight:bold; font-size:1.1rem; color:#2563eb;">${kebutuhanAirLiters} Liter</span>
        </div>
        <div style="font-size:0.8rem; color:var(--color-text-light); line-height:1.4;">
            *Catatan Medis: Estimasi untuk pendakian pulang-pergi (PP) sekitar ~${Math.round(hours)} jam perjalanan aktif. Pastikan membawa snack berkalori tinggi (coklat/kurma) untuk mengganti defisit kalori, dan jangan sepelekan cadangan air.
        </div>
    `;
    lucide.createIcons();
}

// =====================================================
// FITUR 5: LIVE MOUNTAIN WEATHER (Suhu Puncak Spesifik)
// =====================================================
window.fetchMountainWeather = async function(m) {
    const container = document.getElementById('weather-container');
    if (!container) return;
    
    try {
        // Ambil data hourly untuk suhu dan angin. Menggunakan koordinat presisi.
        // Parameter elevation di Open-Meteo akan mencoba mencari model di ketinggian tersebut jika didukung, atau kita bisa adjust lapse rate manual.
        const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${m.coords[0]}&longitude=${m.coords[1]}&current=temperature_2m,wind_speed_10m,weather_code&timezone=Asia%2FJakarta`);
        const data = await res.json();
        
        if (data && data.current) {
            const temp = data.current.temperature_2m;
            const wind = data.current.wind_speed_10m;
            const code = data.current.weather_code;
            
            // Konversi kasar WMO code ke icon (Cerah, Berawan, Hujan)
            let icon = 'cloud-sun';
            let desc = 'Cerah / Berawan';
            if (code >= 51 && code <= 67) { icon = 'cloud-rain'; desc = 'Hujan Ringan-Sedang'; }
            if (code >= 71 && code <= 99) { icon = 'cloud-lightning'; desc = 'Hujan Badai / Ekstrem'; }
            if (code <= 3) { icon = 'sun'; desc = 'Cerah Terang'; }

            // Lapse rate koreksi suhu manual (turun 0.65C tiap 100m) jika API mengambil suhu kaki gunung
            // Kita anggap API sudah lumayan dekat, tapi kita apply koreksi ringan (misal asumsikan API elevasinya 1000m di bawah puncak jika puncak sangat tinggi)
            // Untuk amannya kita tampilkan apa adanya dari API krn Open-Meteo punya resolusi elevasi lumayan baik, tapi tambahkan disclaimer.
            
            const feelsLike = Math.round(temp - (wind * 0.2)); // Kasar windchill

            container.innerHTML = `
                <div class="weather-widget">
                    <div style="font-size: 3rem;"><i data-lucide="${icon}" style="width:48px; height:48px;"></i></div>
                    <div style="flex:1;">
                        <div style="font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px; opacity: 0.8;">Kondisi Puncak Saat Ini</div>
                        <div style="font-size: 2rem; font-weight: bold; margin: 5px 0;">${temp}°C</div>
                        <div style="font-size: 1rem; opacity: 0.9;">${desc}</div>
                    </div>
                    <div style="text-align:right; font-size:0.85rem; border-left: 1px solid rgba(255,255,255,0.3); padding-left:15px;">
                        <div style="margin-bottom:8px;"><i data-lucide="wind" style="width:14px; display:inline-block; vertical-align:middle;"></i> Angin: ${wind} km/j</div>
                        <div><i data-lucide="thermometer-snowflake" style="width:14px; display:inline-block; vertical-align:middle;"></i> Feels like: ${feelsLike}°C</div>
                    </div>
                </div>
            `;
            lucide.createIcons();
        } else {
            throw new Error("Data tidak lengkap");
        }
    } catch (e) {
        container.innerHTML = `<div style="text-align:center; color:var(--color-danger); padding:10px;">Gagal memuat cuaca puncak. Mode Offline.</div>`;
    }
}

// Note: Sunrise/Sunset window function has been removed.

// =====================================================
// FITUR 6: AI PENDAMPING PENDAKIAN (Gratis via Pollinations)
// =====================================================
window.startAICompanion = function() {
    document.getElementById('ai-modal').style.display = 'flex';
}

window.sendAIMessage = async function() {
    const input = document.getElementById('ai-input');
    const msg = input.value.trim();
    if (!msg) return;
    
    const chatBox = document.getElementById('ai-chat-box');
    
    // Tampilkan pesan User
    const userHtml = `
        <div style="align-self:flex-end; background:var(--color-primary); color:white; padding:10px 15px; border-radius:15px 15px 0 15px; max-width:85%; line-height:1.4;">
            ${msg}
        </div>
    `;
    chatBox.insertAdjacentHTML('beforeend', userHtml);
    input.value = '';
    
    // Tampilkan indikator Loading
    const loadingId = 'loading-' + Date.now();
    const loadingHtml = `
        <div id="${loadingId}" style="align-self:flex-start; background:var(--color-bg); padding:10px 15px; border-radius:15px 15px 15px 0; border:1px solid var(--color-border); max-width:85%; display:flex; align-items:center; gap:8px;">
            <i data-lucide="loader" class="spin"></i> Memikirkan jawaban...
        </div>
    `;
    chatBox.insertAdjacentHTML('beforeend', loadingHtml);
    lucide.createIcons();
    chatBox.scrollTop = chatBox.scrollHeight;

    // Local Smart AI Logic (Offline / Rule-based)
    setTimeout(() => {
        document.getElementById(loadingId).remove();
        
        const q = msg.toLowerCase();
        let text = "";
        
        if (q.includes("halo") || q.includes("hai") || q.includes("hi")) {
            text = "Halo sobat pendaki! Ada yang bisa saya bantu terkait rute, perlengkapan, atau kondisi gunung hari ini?";
        } else if (q.includes("alat") || q.includes("bawa apa") || q.includes("perlengkapan") || q.includes("persiapan")) {
            text = "Untuk mendaki, pastikan membawa perlengkapan dasar: Tenda dobel layer, sleeping bag yang mumpuni (suhu minus), jaket windproof/waterproof, matras, headlamp, sepatu gunung (trekking shoes), jas hujan, dan logistik yang cukup. Jangan lupakan kotak P3K pribadi ya!";
        } else if (q.includes("hujan") || q.includes("badai") || q.includes("cuaca") || q.includes("dingin")) {
            text = "Jika terjadi cuaca buruk atau hujan lebat, sangat disarankan untuk menunda perjalanan ke puncak (summit attack). Tetap berlindung di dalam tenda, gunakan pakaian kering agar tidak hipotermia, dan seduh minuman hangat. Keselamatan adalah prioritas utama!";
        } else if (q.includes("simaksi") || q.includes("izin") || q.includes("daftar") || q.includes("syarat")) {
            text = "SIMAKSI (Surat Izin Masuk Kawasan Konservasi) adalah syarat wajib. Anda bisa mengecek website resmi Taman Nasional gunung tujuan, atau daftar langsung di basecamp (On The Spot). Jangan lupa bawa fotokopi KTP dan **Surat Keterangan Sehat dari klinik/puskesmas**.";
        } else if (q.includes("pemula") || q.includes("baru pertama") || q.includes("gampang") || q.includes("mudah")) {
            text = "Untuk pendaki pemula, pilihlah gunung dengan trek landai dan waktu tempuh singkat seperti Gunung Prau, Andong, Batur, atau Papandayan. Ingat, wajib latihan fisik (jogging/kardio) minimal 2-4 minggu sebelum hari H!";
        } else if (q.includes("makanan") || q.includes("logistik") || q.includes("cemilan") || q.includes("air")) {
            text = "Bawa makanan berkalori tinggi namun ringan dibawa: Cokelat, kurma, madu, atau energi bar. Untuk makanan berat, beras, sosis, dan sarden sangat praktis. Siapkan air minimal 3 Liter per orang untuk pendakian standar 2 Hari 1 Malam.";
        } else if (q.includes("terima kasih") || q.includes("makasih") || q.includes("thanks")) {
            text = "Sama-sama! Selalu ingat 3 prinsip utama pendaki: Jangan mengambil apapun selain foto, jangan tinggalkan apapun selain jejak, dan jangan bunuh apapun selain waktu. Salam lestari!";
        } else {
            text = "Pertanyaan yang sangat bagus! Sebagai asisten sistem lokal, saya menyarankan Anda untuk mengecek kolom **'Deskripsi & Karakteristik'** serta **'Persiapan Ekstra'** di halaman profil gunung ini. Pastikan Anda menghubungi pihak basecamp resmi untuk info yang lebih spesifik. Tetap utamakan keselamatan (safety first)!";
        }
        
        // Tampilkan balasan AI
        const aiHtml = `
            <div style="align-self:flex-start; background:var(--color-bg); padding:10px 15px; border-radius:15px 15px 15px 0; border:1px solid var(--color-border); box-shadow:0 4px 6px rgba(0,0,0,0.05); max-width:85%; line-height:1.5;">
                ${text}
            </div>
        `;
        chatBox.insertAdjacentHTML('beforeend', aiHtml);
        chatBox.scrollTop = chatBox.scrollHeight;
    }, 800); // Fake delay for realism
}
window.renderSurvival = function() {
    const html = `
        <div class="container py-5">
            <div style="background:#dc3545; color:white; padding:25px; border-radius:12px; text-align:center; box-shadow:0 10px 30px rgba(220,53,69,0.3);">
                <i data-lucide="radio-tower" style="width:48px; height:48px; margin-bottom:15px; animation: pulse 2s infinite;"></i>
                <h1 style="font-family:var(--font-display); margin:0 0 10px 0; font-size:2.5rem;">Survival Mode</h1>
                <p style="opacity:0.9; font-size:1rem; max-width:500px; margin:0 auto;">Fitur keselamatan darurat. Menggunakan GPS satelit untuk mengetahui koordinat persis Anda bahkan saat offline.</p>
            </div>
            
            <div class="grid" style="grid-template-columns: 1fr 1fr; margin-top:30px;">
                <div class="detail-card" style="text-align:center;">
                    <h3 style="color:var(--color-primary);"><i data-lucide="map-pin"></i> Koordinat Saat Ini</h3>
                    <div id="gps-status" style="margin:20px 0; font-size:1.1rem; color:var(--color-text-light);">Menunggu sinyal GPS...</div>
                    <div style="display:flex; justify-content:center; gap:10px; margin-top:20px;">
                        <div style="background:var(--color-bg); padding:15px; border-radius:8px; border:1px solid var(--color-border); flex:1;">
                            <div style="font-size:0.8rem; color:var(--color-text-light);">Latitude</div>
                            <div id="gps-lat" style="font-weight:bold; font-size:1.2rem; margin-top:5px;">-</div>
                        </div>
                        <div style="background:var(--color-bg); padding:15px; border-radius:8px; border:1px solid var(--color-border); flex:1;">
                            <div style="font-size:0.8rem; color:var(--color-text-light);">Longitude</div>
                            <div id="gps-lng" style="font-weight:bold; font-size:1.2rem; margin-top:5px;">-</div>
                        </div>
                    </div>
                </div>
                
                <div class="detail-card" style="text-align:center;">
                    <h3 style="color:var(--color-accent);"><i data-lucide="mountain"></i> Altimeter & Kompas</h3>
                    <div style="margin:20px 0; display:flex; justify-content:center; align-items:center; gap:30px; flex-wrap:wrap;">
                        <div>
                            <div style="font-size:3rem; font-weight:900; color:var(--color-accent); line-height:1;" id="gps-alt">-</div>
                            <div style="font-size:0.9rem; color:var(--color-text-light); margin-top:5px;">mdpl (Estimasi)</div>
                        </div>
                        <div style="width:120px; height:120px; border-radius:50%; border:4px solid var(--color-primary); position:relative; display:flex; align-items:center; justify-content:center; background:var(--color-card-bg); box-shadow:inset 0 0 10px rgba(0,0,0,0.1);">
                            <!-- Compass Markings -->
                            <div style="position:absolute; top:2px; font-weight:bold; color:var(--color-danger); font-size:12px;">U</div>
                            <div style="position:absolute; bottom:2px; font-weight:bold; color:var(--color-text-light); font-size:12px;">S</div>
                            <div style="position:absolute; right:4px; font-weight:bold; color:var(--color-text-light); font-size:12px;">T</div>
                            <div style="position:absolute; left:4px; font-weight:bold; color:var(--color-text-light); font-size:12px;">B</div>
                            
                            <!-- Rotating Needle -->
                            <div id="compass-needle" style="width:4px; height:100px; position:absolute; transition:transform 0.1s ease-out; transform-origin:center; z-index:2;">
                                <div style="width:100%; height:50%; background:var(--color-danger); border-top-left-radius:4px; border-top-right-radius:4px;"></div>
                                <div style="width:100%; height:50%; background:var(--color-text-light); border-bottom-left-radius:4px; border-bottom-right-radius:4px;"></div>
                            </div>
                            <!-- Center Dot -->
                            <div style="width:12px; height:12px; background:var(--color-primary); border-radius:50%; position:absolute; z-index:3;"></div>
                        </div>
                    </div>
                    <button class="btn btn-outline" style="padding:6px 15px; font-size:0.8rem; margin-top:10px;" onclick="window.requestCompassPermission()">Aktifkan / Kalibrasi Kompas</button>
                    <div id="compass-status" style="font-size:0.8rem; color:var(--color-text-light); margin-top:10px;">Tekan tombol di atas untuk menyalakan sensor</div>
                </div>
            </div>

            <div style="margin-top:30px; text-align:center;">
                <button id="btn-sos" class="btn" style="background:#dc3545; color:white; padding:15px 40px; font-size:1.3rem; font-weight:bold; border-radius:50px; box-shadow:0 5px 20px rgba(220,53,69,0.4); display:inline-flex; align-items:center; gap:10px;" onclick="window.sendSOS()">
                    <i data-lucide="siren" style="width:24px; height:24px;"></i> KIRIM PESAN S.O.S DARURAT
                </button>
                <p style="font-size:0.85rem; color:var(--color-text-light); margin-top:15px;">Tombol ini akan memformat pesan WhatsApp berisi lokasi presisi Anda ke kontak Tim SAR / Keluarga.</p>
            </div>
        </div>
    `;
    appRoot.innerHTML = html;
    lucide.createIcons();

    // Start GPS Tracking
    if ('geolocation' in navigator) {
        navigator.geolocation.watchPosition(pos => {
            document.getElementById('gps-status').innerHTML = '<span style="color:#10b981; font-weight:bold;">Sinyal Terkunci</span>';
            window.lastLat = pos.coords.latitude.toFixed(6);
            window.lastLng = pos.coords.longitude.toFixed(6);
            document.getElementById('gps-lat').innerText = window.lastLat;
            document.getElementById('gps-lng').innerText = window.lastLng;
            
            if (pos.coords.altitude !== null) {
                document.getElementById('gps-alt').innerText = Math.round(pos.coords.altitude);
            } else {
                document.getElementById('gps-alt').innerText = 'N/A';
            }
        }, err => {
            document.getElementById('gps-status').innerHTML = '<span style="color:#dc3545;">Sinyal GPS Hilang/Ditolak</span>';
        }, { enableHighAccuracy: true });
    } else {
        document.getElementById('gps-status').innerText = 'Perangkat tidak mendukung GPS';
    }
}

window.requestCompassPermission = function() {
    const statusDiv = document.getElementById('compass-status');
    
    // Feature detect iOS 13+
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
        DeviceOrientationEvent.requestPermission()
            .then(permissionState => {
                if (permissionState === 'granted') {
                    startCompass(statusDiv);
                } else {
                    statusDiv.innerHTML = '<span style="color:var(--color-danger);">Izin sensor ditolak</span>';
                }
            })
            .catch(console.error);
    } else {
        // Android and non-iOS 13+ devices
        startCompass(statusDiv);
    }
}

function startCompass(statusDiv) {
    if (window.DeviceOrientationEvent) {
        window.addEventListener('deviceorientation', event => {
            let heading = null;
            if (event.webkitCompassHeading) {
                heading = event.webkitCompassHeading; // iOS
            } else if (event.alpha !== null) {
                // Android (alpha is from 0 to 360)
                heading = 360 - event.alpha;
            }
            
            if (heading !== null) {
                document.getElementById('compass-needle').style.transform = `rotate(${heading}deg)`;
                statusDiv.innerHTML = `<span style="color:#10b981;">Sensor Berjalan (${Math.round(heading)}°)</span>`;
            } else {
                statusDiv.innerHTML = 'Data orientasi kosong. Harap goyangkan HP perlahan membentuk angka 8.';
            }
        }, true);
    } else {
        statusDiv.innerHTML = '<span style="color:var(--color-danger);">Sensor tidak didukung</span>';
    }
}

window.sendSOS = function() {
    if (!window.lastLat || !window.lastLng) {
        alert("Sinyal GPS belum terkunci. Pastikan Anda berada di area terbuka.");
        return;
    }
    const msg = `*S.O.S DARURAT PENDAKIAN*\n\nSaya membutuhkan bantuan evakuasi segera. Berikut adalah posisi presisi saya dari pelacak GPS Satelit:\n\nLatitude: ${window.lastLat}\nLongitude: ${window.lastLng}\nGoogle Maps: https://www.google.com/maps?q=${window.lastLat},${window.lastLng}\n\nTolong segera hubungi Tim SAR terdekat!`;
    window.open('https://wa.me/?text=' + encodeURIComponent(msg), '_blank');
}
