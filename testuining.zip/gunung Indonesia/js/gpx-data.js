const gpxData = {
    'prau': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Patak Banteng</name><trkseg>
    <trkpt lat="-7.2023" lon="109.9248"><ele>1900</ele></trkpt>
    <trkpt lat="-7.1950" lon="109.9240"><ele>2200</ele></trkpt>
    <trkpt lat="-7.1860" lon="109.9230"><ele>2590</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'merbabu': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Selo</name><trkseg>
    <trkpt lat="-7.481" lon="110.450"><ele>1800</ele></trkpt>
    <trkpt lat="-7.470" lon="110.448"><ele>2100</ele></trkpt>
    <trkpt lat="-7.465" lon="110.445"><ele>2500</ele></trkpt>
    <trkpt lat="-7.460" lon="110.442"><ele>2800</ele></trkpt>
    <trkpt lat="-7.453" lon="110.439"><ele>3145</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'slamet': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Bambangan</name><trkseg>
    <trkpt lat="-7.240" lon="109.200"><ele>1500</ele></trkpt>
    <trkpt lat="-7.243" lon="109.202"><ele>2200</ele></trkpt>
    <trkpt lat="-7.245" lon="109.205"><ele>2800</ele></trkpt>
    <trkpt lat="-7.248" lon="109.208"><ele>3428</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'sumbing': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Garung</name><trkseg>
    <trkpt lat="-7.380" lon="110.070"><ele>1400</ele></trkpt>
    <trkpt lat="-7.382" lon="110.072"><ele>2100</ele></trkpt>
    <trkpt lat="-7.384" lon="110.075"><ele>2700</ele></trkpt>
    <trkpt lat="-7.388" lon="110.078"><ele>3371</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'sindoro': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Kledung</name><trkseg>
    <trkpt lat="-7.300" lon="109.990"><ele>1400</ele></trkpt>
    <trkpt lat="-7.302" lon="109.992"><ele>2000</ele></trkpt>
    <trkpt lat="-7.305" lon="109.995"><ele>2600</ele></trkpt>
    <trkpt lat="-7.308" lon="109.998"><ele>3150</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'merapi': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur New Selo</name><trkseg>
    <trkpt lat="-7.540" lon="110.440"><ele>1600</ele></trkpt>
    <trkpt lat="-7.542" lon="110.442"><ele>2200</ele></trkpt>
    <trkpt lat="-7.545" lon="110.445"><ele>2600</ele></trkpt>
    <trkpt lat="-7.548" lon="110.448"><ele>2930</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'lawu': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Cemoro Sewu</name><trkseg>
    <trkpt lat="-7.620" lon="111.190"><ele>1800</ele></trkpt>
    <trkpt lat="-7.623" lon="111.192"><ele>2400</ele></trkpt>
    <trkpt lat="-7.625" lon="111.195"><ele>2800</ele></trkpt>
    <trkpt lat="-7.628" lon="111.198"><ele>3265</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'semeru': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Ranu Pane</name><trkseg>
    <trkpt lat="-8.100" lon="112.920"><ele>2100</ele></trkpt>
    <trkpt lat="-8.105" lon="112.922"><ele>2400</ele></trkpt>
    <trkpt lat="-8.108" lon="112.925"><ele>2700</ele></trkpt>
    <trkpt lat="-8.110" lon="112.928"><ele>3676</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'arjuno': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Tretes</name><trkseg>
    <trkpt lat="-7.760" lon="112.580"><ele>800</ele></trkpt>
    <trkpt lat="-7.765" lon="112.585"><ele>1600</ele></trkpt>
    <trkpt lat="-7.768" lon="112.588"><ele>2500</ele></trkpt>
    <trkpt lat="-7.770" lon="112.590"><ele>3339</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'kerinci': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Kersik Tuo</name><trkseg>
    <trkpt lat="-1.690" lon="101.260"><ele>1500</ele></trkpt>
    <trkpt lat="-1.695" lon="101.265"><ele>2200</ele></trkpt>
    <trkpt lat="-1.698" lon="101.268"><ele>3000</ele></trkpt>
    <trkpt lat="-1.700" lon="101.270"><ele>3805</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'agung': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Besakih</name><trkseg>
    <trkpt lat="-8.340" lon="115.500"><ele>1100</ele></trkpt>
    <trkpt lat="-8.345" lon="115.505"><ele>1800</ele></trkpt>
    <trkpt lat="-8.348" lon="115.508"><ele>2400</ele></trkpt>
    <trkpt lat="-8.350" lon="115.510"><ele>3031</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'rinjani': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Sembalun</name><trkseg>
    <trkpt lat="-8.410" lon="116.450"><ele>1150</ele></trkpt>
    <trkpt lat="-8.415" lon="116.455"><ele>1900</ele></trkpt>
    <trkpt lat="-8.418" lon="116.458"><ele>2600</ele></trkpt>
    <trkpt lat="-8.420" lon="116.460"><ele>3726</ele></trkpt>
  </trkseg></trk>
</gpx>`,
    'tambora': `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="PuncakNusantara">
  <trk><name>Jalur Pancasila</name><trkseg>
    <trkpt lat="-8.240" lon="117.990"><ele>500</ele></trkpt>
    <trkpt lat="-8.245" lon="117.995"><ele>1300</ele></trkpt>
    <trkpt lat="-8.248" lon="117.998"><ele>2100</ele></trkpt>
    <trkpt lat="-8.250" lon="118.000"><ele>2850</ele></trkpt>
  </trkseg></trk>
</gpx>`
};
